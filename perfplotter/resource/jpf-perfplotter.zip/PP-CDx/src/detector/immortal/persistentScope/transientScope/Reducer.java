/**
 * 
 * Copyright (c) 2001-2010, Purdue University
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of the Purdue University nor the
 *     names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

package immortal.persistentScope.transientScope;

import immortal.Constants;
import javacp.util.ArrayList;
import javacp.util.HashMap;
import javacp.util.Iterator;
import javacp.util.LinkedList;

/**
 * Reduces the set of possible collisions by using a voxel drawing algorithm.
 * 
 * @author Filip Pizlo, Jeff Hagelberg
 */
public class Reducer {

	/** Creates a Vector2d that represents a voxel. */
	protected void voxelHash(Vector3d position, Vector2d voxel) {
		float x_div = (position.x / voxel_size);
		voxel.x = voxel_size * (x_div);
		if (position.x < 0.0f) voxel.x -= voxel_size;

		float y_div = (position.y / voxel_size);
		voxel.y = voxel_size * (y_div);
		if (position.y < 0.0f) voxel.y -= voxel_size;
	}

	/** Puts a Motion object into the voxel map at a voxel. */
	protected void putIntoMap(HashMap voxel_map, Vector2d voxel, Motion motion) {
		if (!voxel_map.containsKey(voxel)) {
			voxel_map.put(new Vector2d(voxel), new ArrayList());
		}
		((ArrayList) voxel_map.get(voxel)).add(motion);
	}

	/**
	 * Given a voxel and a Motion, determines if they overlap.
	 */
	protected boolean isInVoxel(Vector2d voxel, Motion motion) {
		if (voxel.x > Constants.MAX_X || voxel.x + voxel_size < Constants.MIN_X || voxel.y > Constants.MAX_Y
				|| voxel.y + voxel_size < Constants.MIN_Y) return false;

		// this code detects intersection between a line segment and a square 
		// (geometric intersection, it ignores the time and speeds of aircraft)
		//
		// the intuition is that we transform the coordinates such that the line segment
		// ends up being a line from (0,0) to (1,1) ; in this transformed system, the coordinates of
		// the square (becomes rectangle) are (low_x,low_y,high_x,high_y) ; in this transformed system,
		// it is possible to detect the intersection without further arithmetics (just need comparisons)
		//
		// this algorithm is probably of general use ; I have seen too many online posts advising
		// more complex solution to the problem that involved calculating intersections between rectangle
		// sides and the segment/line
			
		Vector3d init = motion.getFirstPosition();
		Vector3d fin = motion.getSecondPosition();

		float v_s = voxel_size; 
		float r = Constants.PROXIMITY_RADIUS / 2.0f;

		float v_x = voxel.x;
		float x0 = init.x;
		float xv = fin.x - init.x;
		
		float v_y = voxel.y;
		float y0 = init.y;
		float yv = fin.y - init.y;
		
		if (xv == 0.0f || yv == 0.0f) {
			//System.out.println("POSSIBLY WRONG BUG FIX!!!");
			return false;
		}
		
		float low_x, high_x;
		low_x = (v_x - r - x0) / xv;
		high_x = (v_x + v_s + r - x0) / xv;

		if (xv < 0.0f) {
			float tmp = low_x;
			low_x = high_x;
			high_x = tmp;
		}

		float low_y, high_y;
		low_y = (v_y - r - y0) / yv;
		high_y = (v_y + v_s + r - y0) / yv;

		if (yv < 0.0f) {
			float tmp = low_y;
			low_y = high_y;
			high_y = tmp;
		}
		// ugliest expression ever.
		boolean result = (
			(
			(xv == 0.0 && v_x <= x0 + r && x0 - r <= v_x + v_s) /* no motion in x */ || 
				((low_x <= 1.0f && 1.0f <= high_x) || (low_x <= 0.0f && 0.0f <= high_x) || (0.0f <= low_x && high_x <= 1.0f))
			)
			&& 
			(
			(yv == 0.0 && v_y <= y0 + r && y0 - r <= v_y + v_s) /* no motion in y */ || 
				((low_y <= 1.0f && 1.0f <= high_y) || (low_y <= 0.0f && 0.0f <= high_y) || (0.0f <= low_y && high_y <= 1.0f))
			) 
			&& 
			(xv == 0.0f || yv == 0.0f || /* no motion in x or y or both */
					(low_y <= high_x && high_x <= high_y) || (low_y <= low_x && low_x <= high_y) || (low_x <= low_y && high_y <= high_x))
		);
		return result;
	}

	protected void dfsVoxelHashRecurse(Motion motion, Vector2d next_voxel, HashMap voxel_map, HashMap graph_colors) {
		Vector2d tmp = new Vector2d();

		if (isInVoxel(next_voxel, motion) && !graph_colors.containsKey(next_voxel)) {
			graph_colors.put(new Vector2d(next_voxel), "");
			putIntoMap(voxel_map, next_voxel, motion);

			// left boundary
			VectorMath.subtract(next_voxel, horizontal, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// right boundary
			VectorMath.add(next_voxel, horizontal, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// upper boundary
			VectorMath.add(next_voxel, vertical, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// lower boundary
			VectorMath.subtract(next_voxel, vertical, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// upper-left
			VectorMath.subtract(next_voxel, horizontal, tmp);
			VectorMath.add(tmp, vertical, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// upper-right
			VectorMath.add(next_voxel, horizontal, tmp);
			VectorMath.add(tmp, vertical, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// lower-left
			VectorMath.subtract(next_voxel, horizontal, tmp);
			VectorMath.subtract(tmp, vertical, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);

			// lower-right
			VectorMath.add(next_voxel, horizontal, tmp);
			VectorMath.subtract(tmp, vertical, tmp);
			dfsVoxelHashRecurse(motion, tmp, voxel_map, graph_colors);
		}
	}

	/**
	 * Colors all of the voxels that overlap the Motion.
	 */
	protected void performVoxelHashing(Motion motion, HashMap voxel_map, HashMap graph_colors) {
		graph_colors.clear();
		Vector2d voxel = new Vector2d();
		voxelHash(motion.getFirstPosition(), voxel);
		dfsVoxelHashRecurse(motion, voxel, voxel_map, graph_colors);
	}

	/**
	 * Takes a List of Motions and returns an List of Lists of Motions, where the inner lists
	 * implement RandomAccess. Each Vector of Motions that is returned represents a set of Motions
	 * that might have collisions.
	 */
	public LinkedList reduceCollisionSet(LinkedList motions) {

		HashMap voxel_map = new HashMap();
		HashMap graph_colors = new HashMap();

		for (Iterator iter = motions.iterator(); iter.hasNext();)
			performVoxelHashing((Motion) iter.next(), voxel_map, graph_colors);

		LinkedList ret = new LinkedList();
		for (Iterator iter = voxel_map.values().iterator(); iter.hasNext();) {
			ArrayList cur_set = (ArrayList) iter.next();
			if (cur_set.size() > 1) ret.add(cur_set);
		}
		return ret;
	}
	
	public void reduceCollisionSetSimplified(LinkedList motions) {

		HashMap voxel_map = new HashMap();
		HashMap graph_colors = new HashMap();

		for (Iterator iter = motions.iterator(); iter.hasNext();)
			performVoxelHashing((Motion) iter.next(), voxel_map, graph_colors);
	}
	
	/** The voxel size. Each voxel is a square, so the is the length of a side. */
	public float voxel_size;

	/** The horizontal side of a voxel. */
	public Vector2d horizontal;

	/** The vertical side of a voxel. */
	public Vector2d vertical;

	/** Initialize with a voxel size. */
	public Reducer(float voxel_size) {
		this.voxel_size = voxel_size;
		horizontal = new Vector2d(voxel_size, 0.0f);
		vertical = new Vector2d(0.0f, voxel_size);
	}
	
	public static void main(String[] args) {
		LinkedList motions = new LinkedList();
		
		Vector3d s0 = new Vector3d(-2.8038706454867217f, 10.0f, 2.2043656804259886f);
		Vector3d e0 = new Vector3d(10.0f, -1.5536585721019662f, 7.097496661456482f);
		Motion m0 = new Motion(null, s0, e0);
		motions.add(m0);
		
		Vector3d s1 = new Vector3d(-0.4194809659755716f, -8.130887079166625f, -9.79003641384269f);
		Vector3d e1 = new Vector3d(4.502971075324428f, 1.4257580507800878f, -9.02930582203195f);
		Motion m1 = new Motion(null, s1, e1);
		motions.add(m1);
		
		Vector3d s2 = new Vector3d(-5.466095746329334f, -2.3527176337667814f, -6.595065491899373f);
		Vector3d e2 = new Vector3d(7.661796578157819f, -9.498007900416196f, 7.240520116780161f);
		Motion m2 = new Motion(null, s2, e2);
		motions.add(m2);
		
		Vector3d s3 = new Vector3d(7.374527420266407f, 6.371971278879933f, -4.053592436293362f);
		Vector3d e3 = new Vector3d(-0.9292910533816077f, -3.2682968510384107f, -9.788795427233213f);
		Motion m3 = new Motion(null, s3, e3);
		motions.add(m3);
		
		Vector3d s4 = new Vector3d(-2.7740958073704185f, -0.40164893492291043f, 7.196760285977497f);
		Vector3d e4 = new Vector3d(8.913685247021746f, -0.699601795713507f, -1.440521786668194f);
		Motion m4 = new Motion(null, s4, e4);
		motions.add(m4);
		
		Vector3d s5 = new Vector3d(-9.823484564167892f, -2.534631522952191f, -3.5956141771155554f);
		Vector3d e5 = new Vector3d(-6.366458009936662f, -6.651440386041562f, -2.95284836172155f);
		Motion m5 = new Motion(null, s5, e5);
		motions.add(m5);
		
		Vector3d s6 = new Vector3d(0.045297788906426106f, -3.661982245019793f, 2.5847338774148483f);
		Vector3d e6 = new Vector3d(9.33302127464001f, 1.5421610730927053f, -3.1216242436287462f);
		Motion m6 = new Motion(null, s6, e6);
		motions.add(m6);
		
		Vector3d s7 = new Vector3d(-5.267898134704798f, 1.9578405154160006f, -1.8981485065871766f);
		Vector3d e7 = new Vector3d(1.2190976287139215f, -0.3050789963231253f, -8.22264217468115f);
		Motion m7 = new Motion(null, s7, e7);
		motions.add(m7);
		
		Vector3d s8 = new Vector3d(-0.4138367486580883f, 0.4377867859683633f, 6.089869009856574f);
		Vector3d e8 = new Vector3d(1.2855398843237626f, 5.863318390945922f, -8.428398801077817f);
		Motion m8 = new Motion(null, s8, e8);
		motions.add(m8);
		
		Vector3d s9 = new Vector3d(-2.1408123502577325f, -4.303925775414834f, -4.248158377068101f);
		Vector3d e9 = new Vector3d(-1.6074752105395103f, -8.775085805262046f, -7.801097344781763f);
		Motion m9 = new Motion(null, s9, e9);
		motions.add(m9);
			
		long start = System.currentTimeMillis();
		new Reducer(immortal.Constants.GOOD_VOXEL_SIZE).reduceCollisionSetSimplified(motions);
		System.out.println(System.currentTimeMillis() - start);
	}
}
