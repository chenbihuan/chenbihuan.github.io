package apollo;

import apollo.Reaction_Jet_Control0;

public class rjc {
	private Reaction_Jet_Control0 Reaction_Jet_Control_100000006_class_member0 = new Reaction_Jet_Control0();

	public void Main0(double[] In1_2, double[] In2_3, double[] Out1_4, double[] Out2_5) {
		Reaction_Jet_Control_100000006_class_member0.Main1(In1_2, In2_3, Out1_4, Out2_5);
	}

	public void Init2() {
		Reaction_Jet_Control_100000006_class_member0.Init3();
	}

	// Added by hand so that symbolic pathfinder can be used
	public void MainSymbolic1(double in11_0, double in11_1, double in11_2, double in12_0, double in12_1, double in12_2, double[] out1, double[] out2) {
		double[] in1 = new double[3];
		double[] in2 = new double[3];

		in1[0] = in11_0;
		in1[1] = in11_1;
		in1[2] = in11_2;

		in2[0] = in12_0;
		in2[1] = in12_1;
		in2[2] = in12_2;

		this.Reaction_Jet_Control_100000006_class_member0.Main1(in1, in2, out1, out2);
	}
	
	public void MainSymbolic2(double in21_0, double in21_1, double in21_2, double in22_0, double in22_1, double in22_2, double[] out1, double[] out2) {
		double[] in1 = new double[3];
		double[] in2 = new double[3];

		in1[0] = in21_0;
		in1[1] = in21_1;
		in1[2] = in21_2;

		in2[0] = in22_0;
		in2[1] = in22_1;
		in2[2] = in22_2;

		this.Reaction_Jet_Control_100000006_class_member0.Main1(in1, in2, out1, out2);
	}
}
