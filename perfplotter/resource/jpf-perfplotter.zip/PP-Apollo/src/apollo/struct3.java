package apollo;

public class struct3 {
  public double signal1 = 0;
  public double signal2 = 0;
}

