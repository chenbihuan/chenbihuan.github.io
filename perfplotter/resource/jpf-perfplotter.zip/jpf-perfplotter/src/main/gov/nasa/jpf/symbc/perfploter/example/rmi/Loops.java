package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Loops extends UnicastRemoteObject implements TimeInterface {

	private static final long serialVersionUID = 8488714018845450368L;

	protected Loops() throws RemoteException {
		super();
	}

	public int runSingleLoops(int x, int y) {
		int sum = 0;
		for (int i = 0; i < x; i++) {
			sum += i;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		for (int j = 0; j < y; j++) {
			sum += j;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return sum;
	}
	
	public int runNestedLoops(int x, int y) {
		int sum = 0;
		for (int i = 0; i < x; i++) {
			sum += i;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			for (int j = 0; j < y; j++) {
				sum += j;
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		return sum;
	}

	@Override
	public long measureExecutionTime(Object[] argsValues) throws RemoteException {
		long start = System.currentTimeMillis();
		runNestedLoops((int)argsValues[0], (int)argsValues[1]);
		return System.currentTimeMillis() - start;
	}

}
