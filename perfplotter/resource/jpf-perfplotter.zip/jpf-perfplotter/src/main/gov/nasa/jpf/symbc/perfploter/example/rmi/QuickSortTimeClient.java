package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class QuickSortTimeClient {

	public static void main(String[] args) {
		try {
			TimeInterface time = (TimeInterface) Naming.lookup("rmi://172.21.241.38/gov.nasa.jpf.symbc.perfploter.example.QuickSort.doit7(v1_i,v2_i,v3_i,v4_i,v5_i,v6_i,v7_i)");
			Object[] argsValues = new Object[7];
			argsValues[0] = 88;
			argsValues[1] = 88;
			argsValues[2] = 93;
			argsValues[3] = 98;
			argsValues[4] = 78;
			argsValues[5] = 90;
			argsValues[6] = 88;
			System.out.println(time.measureExecutionTime(argsValues));
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			e.printStackTrace();
		}
	}

}
