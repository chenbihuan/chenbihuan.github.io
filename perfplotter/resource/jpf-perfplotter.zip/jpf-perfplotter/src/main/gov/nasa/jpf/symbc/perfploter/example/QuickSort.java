package gov.nasa.jpf.symbc.perfploter.example;

public class QuickSort {

    private int partition (int[] arr, int left, int right, int pivotIndex) {
        int pivotValue = arr[pivotIndex];
        {
            int t = arr[pivotIndex];
            arr[pivotIndex] = arr[right];
            arr[right] = t;
            try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (arr[i] <= pivotValue) {
                int t = arr[i];
                arr[i] = arr[storeIndex];
                arr[storeIndex] = t;
                storeIndex++;
                try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
            }
        }
        {
            int t = arr[storeIndex];
            arr[storeIndex] = arr[right];
            arr[right] = t;
            try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
        return storeIndex;
    }

    private void quicksort (int[] arr, int left, int right) {
        if (right > left) {            
            int pivotIndex = left + (right - left) / 2;
            int pivotNewIndex = partition(arr, left, right, pivotIndex);
            quicksort(arr, left, pivotNewIndex - 1);
            quicksort(arr, pivotNewIndex + 1, right);
        }
    }

    public void doit6(int v1, int v2, int v3, int v4, int v5, int v6) {
    	int[] data = new int[6];
    	data[0] = v1;
    	data[1] = v2;
    	data[2] = v3;
    	data[3] = v4;
    	data[4] = v5;
    	data[5] = v6;
    	quicksort(data, 0, data.length - 1);
    }
    
    public void doit7(int v1, int v2, int v3, int v4, int v5, int v6, int v7) {
    	int[] data = new int[7];
    	data[0] = v1;
    	data[1] = v2;
    	data[2] = v3;
    	data[3] = v4;
    	data[4] = v5;
    	data[5] = v6;
    	data[6] = v7;
    	//quicksort(data, 0, data.length - 1);
    	heapsort(data);
    }

    public void doit8(int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8) {
    	int[] data = new int[8];
    	data[0] = v1;
    	data[1] = v2;
    	data[2] = v3;
    	data[3] = v4;
    	data[4] = v5;
    	data[5] = v6;
    	data[6] = v7;
    	data[7] = v8;
    	quicksort(data, 0, data.length - 1);
    }
    
    public static void main(String[] args) {
        QuickSort s = new QuickSort();
        //s.doit6(42,7,23,13,11,19);
        s.doit7(88, 88, 93, 98, 78, 93, 88);
        //s.doit8(88, 88, 93, 98, 78, 93, 88, 23);
    }
    
    // heap sort
    private static int total;

    private static void heapify(int[] arr, int i)
    {
        int lft = i * 2;
        int rgt = lft + 1;
        int grt = i;

        if (lft <= total) {
        	if (arr[lft] > arr[grt]) {
        		grt = lft;
        	}
        	try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
        if (rgt <= total) {
        	if (arr[rgt] > arr[grt]) {
        		grt = rgt;
        	}
        	try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
        if (grt != i) {
        	int tmp = arr[i];
        	arr[i] = arr[grt];
        	arr[grt] = tmp;
            heapify(arr, grt);
        }
    }

    public static void heapsort(int[] arr)
    {
        total = arr.length - 1;

        for (int i = total / 2; i >= 0; i--)
            heapify(arr, i);

        for (int i = total; i > 0; i--) {
            int tmp = arr[0];
            arr[0] = arr[i];
            arr[i] = tmp;
            total--;
            heapify(arr, 0);
        }
    }

}
