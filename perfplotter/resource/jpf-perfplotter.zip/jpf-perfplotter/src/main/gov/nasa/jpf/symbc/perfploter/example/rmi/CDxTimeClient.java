package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class CDxTimeClient {

	public static void main(String[] args) {
		try {
			TimeInterface time = (TimeInterface) Naming.lookup("rmi://172.21.241.198/gov.nasa.jpf.symbc.perfploter.example.rmi.CDx(ls0_f,ws0_f,hs0_f,le0_f,we0_f,he0_f,ls1_f,ws1_f,hs1_f,le1_f,we1_f,he1_f,ls2_f,ws2_f,hs2_f,le2_f,we2_f,he2_f,ls3_f,ws3_f,hs3_f,le3_f,we3_f,he3_f,ls4_f,ws4_f,hs4_f,le4_f,we4_f,he4_f,ls5_f,ws5_f,hs5_f,le5_f,we5_f,he5_f,ls6_f,ws6_f,hs6_f,le6_f,we6_f,he6_f,ls7_f,ws7_f,hs7_f,le7_f,we7_f,he7_f,ls8_f,ws8_f,hs8_f,le8_f,we8_f,he8_f,ls9_f,ws9_f,hs9_f,le9_f,we9_f,he9_f)");
			Object[] argsValues = new Object[60];
			for (int i = 0; i < 60; i++) {
				argsValues[i] = new java.util.Random().nextFloat() * 20f - 10f;
			}
			System.out.println(time.measureExecutionTime(argsValues));
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			e.printStackTrace();
		}
	}

}
