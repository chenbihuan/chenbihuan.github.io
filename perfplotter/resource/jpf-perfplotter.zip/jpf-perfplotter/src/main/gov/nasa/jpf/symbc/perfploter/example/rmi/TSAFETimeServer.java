package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class TSAFETimeServer {

	public static void main(String[] args) {
		try {
			LocateRegistry.createRegistry(1099);
			TimeInterface time = new TSAFE();
			Naming.rebind("gov.nasa.jpf.symbc.perfploter.example.rmi.TSAFE.TestDriver2(latitude1_d,longitude1_d,latitude2_d,longitude2_d)", time);
			System.out.println("Time Server is ready.");
		} catch (RemoteException | MalformedURLException e) {
			e.printStackTrace();
		} 
	}

}