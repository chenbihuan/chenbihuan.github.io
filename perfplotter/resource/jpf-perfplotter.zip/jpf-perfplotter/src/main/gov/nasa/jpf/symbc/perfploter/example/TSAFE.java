package gov.nasa.jpf.symbc.perfploter.example;

import java.io.Reader;

import tsafe.common_datastructures.Flight;
import tsafe.common_datastructures.FlightPlan;
import tsafe.common_datastructures.FlightTrack;
import tsafe.common_datastructures.LatLonBounds;
import tsafe.common_datastructures.TSAFEProperties;
import tsafe.common_datastructures.communication.UserParameters;
import tsafe.server.computation.Calculator;
import tsafe.server.computation.ConformanceMonitor;
import tsafe.server.computation.RouteTrack;
import tsafe.server.computation.RouteTracker;
import tsafe.server.computation.TrajectorySynthesizer;
import tsafe.server.database.RuntimeDatabase;
import tsafe.server.parser.asdi.ASDIParser;

public class TSAFE {

	private String[] msgs = {"000000000000FCMDFZ FL1 T/747/A 0190 4134N/07344W P0000 230 4134N/07344W..4206N/07250W..4242N/07241W..4257N/07223W",
			"000000000000FCMDTZ FL1 200 230 4134N/07344W", "000000000000FCMDTZ FL1 200 230 4139N/07335W", "000000000000FCMDTZ FL1 200 230 4143N/07327W"};
	
	private RouteTracker routeTracker;
	private ConformanceMonitor confMonitor;
	private TrajectorySynthesizer trajSynth;
	private Calculator calculator;
	private RuntimeDatabase database;

	public TSAFE() {
		LatLonBounds bounds = TSAFEProperties.getLatLonBounds();
		UserParameters parameters = new UserParameters();

		calculator = new Calculator();
		database = new RuntimeDatabase(bounds);
		String[] dataFiles = TSAFEProperties.getDataFiles();
		Reader feedReader = TSAFEProperties.getFeedSource();
		ASDIParser feedParser = new ASDIParser(feedReader, database, calculator);
		feedParser.readStaticData(dataFiles);
		feedParser.parseMessage(msgs[0]);
		feedParser.parseMessage(msgs[1]);
		
		routeTracker = new RouteTracker(null, calculator, bounds);
		confMonitor = new ConformanceMonitor(null, calculator, bounds);
		trajSynth = new TrajectorySynthesizer(null, calculator, bounds);
		
		confMonitor.setParameters(parameters);
		routeTracker.setParameters(parameters);
		trajSynth.setParameters(parameters);
	}
	
	public void testDriver(double latitude, double longitude, double altitude, double speed) {
		// denormalize
		longitude = longitude * 2;
		//altitude = (altitude + 180) * 55;
		//speed = (speed + 126) * 0.0015;
							
		Flight flight = (Flight)database.selectFlightsInBounds().iterator().next();
		FlightTrack track = flight.getFlightTrack();
		
		//System.out.println(track.getAltitude() + " " + track.getSpeed());
		
		// If this is the first TZ/UZ message, the heading is set to 0 Otherwise, calculate the heading from previous position
		double heading = track == null ? 0 : calculator.angleLL(track.getLatitude(), track.getLongitude(), latitude, longitude, new LatLonBounds(0, 0, 0, 0));
		flight.setFlightTrack(new FlightTrack(latitude, longitude, altitude, 1433001600000l, speed, heading));
		
		FlightTrack ft = flight.getFlightTrack();
		FlightPlan fp = flight.getFlightPlan();
				
		// determine if a flight is blundering by comparing its actual track to its route track
		RouteTrack rt = routeTracker.findRouteTrack(ft, fp);
		boolean blundering = confMonitor.isBlundering(ft, rt);

		// if the flight is blundering, assign a dead reckoning trajectory as its assigned trajectory
		if (blundering) {
			trajSynth.getDeadReckoningTrajectory(ft);
		}
		// if the flight is conforming, synthesize a route trajectory for it, assuming it's current track is its route track
		else {
			trajSynth.getRouteTrajectory(rt, fp.getRoute());
		}
	}
	
	public void testDriver2(double latitude1, double longitude1, double latitude2, double longitude2) {
		testDriver(latitude1, longitude1, 7010, 0.1029);
		testDriver(latitude2, longitude2, 7010, 0.1029);
	}
	
	public static void main(String[] args) {
		TSAFE t = new TSAFE();
		long start = System.nanoTime();
		t.testDriver2(-50, -70, -50, -70);
		System.out.println(System.nanoTime() - start);
	}

}
