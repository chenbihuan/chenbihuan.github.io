package gov.nasa.jpf.symbc.probsym;

/*
 * This class is just a proxy for Listener interceptions 
 */
public class Analyze {
	
	public static void coverage(String s) {
		// does nothing since it will be intercepted by the ProbSymListener
		// which will print "s" and stats on the probabilities and pc when this method is called
	}

}
