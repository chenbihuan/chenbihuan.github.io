package gov.nasa.jpf.symbc.modelcounter.sampler;

/**
 * An assignment refers to a mapping from unique identifiers (for symbolic variables) to {@code Object}s.
 */
public interface Assignment {

	/**
	 * Return the integer value assignment to the symbolic variables with the given name.
	 * 
	 * @param name the name of the variable
	 * @return the integer value of the variable in the current assignment
	 */
	public int getInt(String name);
	
	/**
	 * Return the double value assignment to the symbolic variables with the given name.
	 * 
	 * @param name the name of the variable
	 * @return the double value of the variable in the current assignment
	 */
	public double getDouble(String name);
	
}
