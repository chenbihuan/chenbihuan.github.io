package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class TreeMapTimeClient {

	public static void main(String[] args) {
		try {
			TimeInterface time = (TimeInterface) Naming.lookup("rmi://172.21.241.38/gov.nasa.jpf.symbc.perfploter.example.TreeMap.runTest(c0_i,c1_i,c2_i,c3_i,c4_i,v5_i,v6_i,v7_i,v8_i,v9_i)");
			Object[] argsValues = new Object[10];
			argsValues[0] = 40;
			argsValues[1] = 24;
			argsValues[2] = 7;
			argsValues[3] = 19;
			argsValues[4] = 82;
			argsValues[5] = 29;
			argsValues[6] = 29;
			argsValues[7] = 56;
			argsValues[8] = 72;
			argsValues[9] = 18;
			for (int k = 0; k < 10; k++) {
				double mean = 0;
				for (int j = 0; j < 10; j++) {
					double sum = 0;
					for (int i = 0; i < 2000; i++) {
						sum += time.measureExecutionTime(argsValues);
					}
					mean += sum / 2000;
				}
				System.out.println(mean / 10);
			}
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			e.printStackTrace();
		}
	}

}
