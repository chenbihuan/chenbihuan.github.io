package gov.nasa.jpf.symbc.perfploter.example;

public class CoralTests {

	public static void test1(float x, float z) {
		int y = 0;;
		if (x == 1000) {
			y = y + 1;
		}
		if (x != 3000) {
			y = y + 1;
		}
	}
	
	public static void test2(float x, float z) {
		int y = 0;
		if (x > 1000) {
			y = y + 1;
		}
		if (x < 3000) {
			y = y + 1;
		}
	}
	
	public static void test3(float x, float z) {
		int y = 0;
		if (x >= 1000) {
			y = y + 1;
		}
		if (x <= 3000) {
			y = y + 1;
		}
	}
	
	public static void test4(float x) {
		int sum = 0;
		for (int i = 0; i < x; i++) {
			sum = sum + i;
		}
	}
	
	public static void test5(int x) {
		if ( x > 100) {
			System.out.println("feasible");
		}
	}
	
	public static void test6(int x) {
		switch(x) {
		case 1: 
			System.out.println(1);
			break;
		case 2:
			System.out.println(2);
			break;
		default:
			System.out.println("default");
			break;
		}
	}
	
	public static void test7(float x, float y) {
		if (x > 1000 && y > 50) {
			System.out.println("success");
		}
	}
	
	public static void main(String[] args) {
		test7(2000, 51);
	}

}
