package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class LoopsTimeClient {

	public static void main(String[] args) {
		try {
			TimeInterface time = (TimeInterface) Naming.lookup("rmi://172.21.241.38/gov.nasa.jpf.symbc.perfploter.example.Loops.runNestedLoops(x_i,y_i)");
			Object[] argsValues = new Object[2];
			argsValues[0] = 100;
			argsValues[1] = 100;
			System.out.println(time.measureExecutionTime(argsValues));
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			e.printStackTrace();
		}
	}

}