package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class LoopsTimeServer {

	public static void main(String[] args) {
		try {
			LocateRegistry.createRegistry(1099);
			TimeInterface time = new Loops();
			Naming.rebind("gov.nasa.jpf.symbc.perfploter.example.Loops.runNestedLoops(x_i,y_i)", time);
			System.out.println("Time Server is ready.");
		} catch (RemoteException | MalformedURLException e) {
			e.printStackTrace();
		} 
	}

}