package gov.nasa.jpf.symbc.perfploter.example;

public class Loops {

	public int runSingleLoops(int x, int y) {
		int sum = 0;
		for (int i = 0; i < x; i++) {
			sum += i;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		for (int j = 0; j < y; j++) {
			sum += j;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return sum;
	}
	
	public int runNestedLoops(int x, int y) {
		int sum = 0;
		for (int i = 0; i < x; i++) {
			sum += i;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			for (int j = 0; j < y; j++) {
				sum += j;
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		return sum;
	}
	
	public static void main(String[] args) {
		new Loops().runNestedLoops(10, 10);
	}

}
