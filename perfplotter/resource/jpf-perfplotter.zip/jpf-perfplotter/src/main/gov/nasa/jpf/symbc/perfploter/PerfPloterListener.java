/*
 * Copyright (C) 2006 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration (NASA).
 * All Rights Reserved.
 * 
 * This software is distributed under the NASA Open Source Agreement (NOSA),
 * version 1.3. The NOSA has been approved by the Open Source Initiative. See
 * the file NOSA-1.3-JPF at the top of the distribution directory tree for the
 * complete NOSA document.
 * 
 * THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY KIND,
 * EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, ANY
 * WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO SPECIFICATIONS, ANY
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL BE
 * ERROR FREE, OR ANY WARRANTY THAT DOCUMENTATION, IF PROVIDED, WILL CONFORM TO
 * THE SUBJECT SOFTWARE.
 */

package gov.nasa.jpf.symbc.perfploter;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.JPF;
import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.search.*;
import gov.nasa.jpf.jvm.BooleanChoiceGenerator;
import gov.nasa.jpf.jvm.ChoiceGenerator;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.GOTO;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.Instruction;
import gov.nasa.jpf.jvm.choice.IntIntervalGenerator;
import gov.nasa.jpf.jvm.choice.ThreadChoiceFromSet;
import gov.nasa.jpf.symbc.SymbolicInstructionFactory;
import gov.nasa.jpf.symbc.heap.HeapChoiceGenerator;
import gov.nasa.jpf.symbc.modelcounter.ModelCounter;
import gov.nasa.jpf.symbc.numeric.Comparator;
import gov.nasa.jpf.symbc.numeric.Constraint;
import gov.nasa.jpf.symbc.numeric.DependencyCalc;
import gov.nasa.jpf.symbc.numeric.PCChoiceGenerator;
import gov.nasa.jpf.symbc.numeric.PathCondition;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apfloat.Apfloat;

public class PerfPloterListener extends ListenerAdapter {

	/**
	 * The model counters invoked to calculate path probabilities. Only the
	 * first model counter's results are really taken into account; the others
	 * are merely there for experimental comparisons.
	 */
	private List<ModelCounter> modelCounters = null;

	/**
	 * Mapping from path conditions to the conditional probability of the last
	 * ("freshest") constraint of each path condition.
	 */
	private Map<String, Apfloat> conditionalMap;

	/**
	 * The previous minimal path condition produced.
	 */
	private PathCondition minimalPC = null;

	/**
	 * The path probability of the current, minimal path condition excluding the
	 * freshest constraint.
	 */
	private Apfloat prior = Apfloat.ZERO;

	/**
	 * Caches (one per model counter) for memorization of calls.
	 */
	private Map<ModelCounter, Map<String, Apfloat>> cache;

	/**
	 * APfloat precision is set here
	 */
	private static final int PRECISION = 500;
	
	/*
	 * Null Probability in Heap Choices
	 */
	private static Apfloat nullProb = Apfloat.ONE.divide(new Apfloat(5, PRECISION)); // 20%
	
	/*
	 * Null Probability in Heap Choices
	 */
	private static Apfloat newProb = Apfloat.ONE.multiply(new Apfloat(7, PRECISION)).divide(new Apfloat(10, PRECISION)); // 70%
	
	/*
	 * Debug flag
	 */
	private boolean debugMode = false;
	
	/**
	 * The number of instructions before starting a transition
	 */
	private long transitionStartInstructions;

	/**
	 * The Search object for instructionExecuted(JVM vm)
	 */
	private Search search;
	
	/**
	 * flag to indicate if state ignoring is needed when merging states for floating-point comparisons
	 */
	private boolean flag = false;
	
	private double delta = 0.00001;
	
	private SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss.SSS");
	
	/**
	 * Constructor.
	 * 
	 * @param conf JPF configuration file
	 * @param jpf main of the JPF verification framework
	 */
	public PerfPloterListener(Config conf, JPF jpf) {		
		String[] dummy = conf.getStringArray("probsym.debug");
		if (dummy != null) {
			debugMode = true;
		} else {
			debugMode = false;
		}
				
		modelCounters = conf.getInstances("symbolic.prob_modelcounter", ModelCounter.class, new Class[] { Config.class }, new Object[] { conf });
		cache = new HashMap<ModelCounter, Map<String, Apfloat>>();
		if ((modelCounters == null) || modelCounters.isEmpty()) {
			modelCounters = new ArrayList<ModelCounter>();
			System.out.println("symbolic.prob_modelcounter=<<NONE SPECIFIED>>");
		} else {
			for (ModelCounter m : modelCounters) {
				System.out.println("symbolic.prob_modelcounter=" + m.getClass().getName());
				cache.put(m, new HashMap<String, Apfloat>());
			}
		}
		
		conditionalMap = new HashMap<String, Apfloat>();
		
		search = jpf.getSearch();
	}
	
	/**
	 * compute the path condition, probability, instruction and diversity whenever a state is advanced
	 */
	@Override
	public void stateAdvanced(Search search) {
		PathCondition pc = getPC(search.getVM());
		if (search instanceof PerfPloterHeuristicSearch) {
			PerfPloterHeuristicSearch s = (PerfPloterHeuristicSearch) search;
			if (pc != null) {
				String info = s.getBranchIfInfo();
				if (info != null && info.contains("(true") && info.contains("ifle")) {
					if (pc.header.getComparator().equals(Comparator.LT)) {
						pc.header.setComparator(Comparator.LE);
						flag = true;
						System.out.println("Flag is true");
					} else if (pc.header.getComparator().equals(Comparator.EQ)) {
						if (flag) {
							search.setIgnoredState(true);
							flag = false;
							System.out.println("Flag is false");
						}
					}
				} else if (info != null && info.contains("(true") && info.contains("ifge")) {
					if (pc.header.getComparator().equals(Comparator.EQ)) {
						pc.header.setComparator(Comparator.GE);
						flag = true;
						System.out.println("Flag is true");
					} else if (pc.header.getComparator().equals(Comparator.GT)) {
						if (flag) {
							search.setIgnoredState(true);
							flag = false;
							System.out.println("Flag is false");
						}
					}
				} else if (info != null && info.contains("(false") && info.contains("iflt")) {
					if (pc.header.getComparator().equals(Comparator.EQ)) {
						pc.header.setComparator(Comparator.GE);
						flag = true;
						System.out.println("Flag is true");
					} else if (pc.header.getComparator().equals(Comparator.GT)) {
						if (flag) {
							search.setIgnoredState(true);
							flag = false;
							System.out.println("Flag is false");
						}
					}
				} else if (info != null && info.contains("(false") && info.contains("ifgt")) {
					if (pc.header.getComparator().equals(Comparator.LT)) {
						pc.header.setComparator(Comparator.LE);
						flag = true;
						System.out.println("Flag is true");
					} else if (pc.header.getComparator().equals(Comparator.EQ)) {
						if (flag) {
							search.setIgnoredState(true);
							flag = false;
							System.out.println("Flag is false");
						}
					}
				} else if (info != null && info.contains("(true") && info.contains("ifne")) {
					if (pc.header.getComparator().equals(Comparator.LT)) {
						pc.header.setComparator(Comparator.NE);
						flag = true;
						System.out.println("Flag is true");
					} else if (pc.header.getComparator().equals(Comparator.GT)) {
						if (flag) {
							search.setIgnoredState(true);
							flag = false;
							System.out.println("Flag is false");
						}
					}
				} else if (info != null && info.contains("(false") && info.contains("ifeq")) {
					if (pc.header.getComparator().equals(Comparator.LT)) {
						pc.header.setComparator(Comparator.NE);
						flag = true;
						System.out.println("Flag is true");
					} else if (pc.header.getComparator().equals(Comparator.GT)) {
						if (flag) {
							search.setIgnoredState(true);
							flag = false;
							System.out.println("Flag is false");
						}
					}
				}
				
				if (!search.isIgnoredState()) {
					System.out.println("Path Condition: " + pc.header.stringPC());
					// path probability, instruction, and diversity
					ProbReturn ret = doUniversalProbCalc(search.getVM().getChoiceGenerator());
					Apfloat prob = ret.prob;
					long instruction = computeInstructions(search.getVM());
					long diversity = search.getDepth() - 1;
					System.out.print(format.format(new Date(System.currentTimeMillis())));
					System.out.println(" Path Probability: " + prob.doubleValue() + ", Path Instruction: " + instruction + ", Path Diversity: " + diversity + "\n");
					assert prob != null; // probably redundant
					// set state information
					s.setPathCondition(pc);
					s.setPathProbability(prob.doubleValue());
					s.setPathInstruction(instruction);
					s.setPathDiversity(diversity);
				} else {
					s.setBranchIfInfo(null);
					s.setNBreakOut(null);
					System.out.println("Mergerd state \n");
				}
			} else {
				s.setBranchIfInfo(null);
				s.setNBreakOut(null);
				System.out.println("Infeasible path");
				flag = false;
				System.out.println("Flag is false \n");
			}
		}
	}
	
	@Override
	public void instructionExecuted(JVM vm) {
		if (vm.getChoiceGenerators().length > 1) {
			Instruction insn = vm.getLastInstruction();
			if (insn.isCompleted(vm.getLastThreadInfo()) && insn instanceof IfInstruction && search instanceof PerfPloterHeuristicSearch) {
				PerfPloterHeuristicSearch s = (PerfPloterHeuristicSearch) search;
				int position = 0;
				boolean loop = false;
				if (s.getLoopIfInstructionStack() != null && s.getLoopIfInstructionStack().size() > 0) {
					loop = true;
					String info = s.getLoopIfInstructionStack().peek();
					position = Integer.valueOf(info.substring(0, info.indexOf(" ")));
				}
				IfInstruction ifinsn = (IfInstruction) insn;
				String info = ifinsn.getPosition() + " " + ifinsn;
				if (ifinsn.getConditionValue() && ifinsn.isBackJump()) { // jump back to the loop
					info += " JUMPBACK";
				} else if (ifinsn.getConditionValue() && loop && ifinsn.getTarget().getPosition() > position) { // break, return
					info += " BREAKOUT_NG";
				} else if (!ifinsn.getConditionValue() && loop && ifinsn.getNext() instanceof GOTO && ((GOTO)ifinsn.getNext()).getTarget().getPosition() > position) { // break, return
					info += " BREAKOUT_GT";
				} else if (!ifinsn.getConditionValue() && loop && ifinsn.getNext().getPosition() > position) {
					info += " BREAKOUT_NM";
				} else {
					info += " COMMON";
				}
				info += " (" + ifinsn.getConditionValue() + ", " + ifinsn.isBackJump() + ")";
				System.out.println(info);
				if (s.getBranchIfInfo() == null) {
					s.setBranchIfInfo(info);
				} else {
					s.setNBreakOut(info);
				}
			}
		}
	}
	
	@Override
	public void searchFinished(Search search) {
		System.out.println();
		if (SymbolicInstructionFactory.solver != null) {
			SymbolicInstructionFactory.solver.shutdown();
			for (String str : SymbolicInstructionFactory.solver.getSolverReport()) {
				System.out.println(str);
			}
		}
		if (modelCounters.size() == 0)
			return;
		for (ModelCounter m : modelCounters) {
			m.report();
		}
	}
	
	@Override
	public void choiceGeneratorRegistered(JVM vm){
		ChoiceGenerator<?> cg = vm.getLastChoiceGenerator();
		ChoiceGenerator<?> cgPrev = cg.getPreviousChoiceGenerator();
	    long t = vm.getCurrentThread().getExecutedInstructions();
	    
		Apfloat af = null;
		if (cg.isCascaded()){
	    	// there's got to be a previous one, and its associated with the same insn
			af = cgPrev.getAttr(Apfloat.class);
		} else {
	    	if (cgPrev != null){
	    		Apfloat apPrev = cgPrev.getAttr(Apfloat.class); // there has to be one
	    		af = new Apfloat(t + apPrev.longValue(), PRECISION); //new TimeVal(tvPrev.time + t);     
	    	} else {
	    		af = new Apfloat(t, PRECISION);
	    	}
	    }
		cg.addAttr(af);
	}
	  
	@Override
	public void choiceGeneratorAdvanced(JVM vm){
		ChoiceGenerator<?> cg = vm.getLastChoiceGenerator();
		Apfloat ap = cg.getAttr(Apfloat.class);
		if (ap != null){
	    	transitionStartInstructions = ap.longValue();
	    } else {
	    	transitionStartInstructions = 0;
	    }
	}
	
	class ProbReturn {
		String desc;
		Apfloat prob;
			
		public ProbReturn(String d, Apfloat p) {
			desc = d;
			prob = p;
		}
	}

	/**
	 * Compute the path probability
	 * @param cg
	 * @return
	 */
	private ProbReturn doUniversalProbCalc(ChoiceGenerator<?> cg) {
		Apfloat pr = new Apfloat(1.0, PRECISION);
		Apfloat p;
		String desc = "";
		while (cg != null) {
			if (cg instanceof PCChoiceGenerator) {
				PathCondition pc =  ((PCChoiceGenerator) cg).getCurrentPC();
				if (debugMode) {
					System.out.println("Found PC CG " + (PCChoiceGenerator)cg);
					System.out.println("PC = " + pc);
				}
				// added by bihuan
				if (pc != null && pc.getSliceOffPathConditionEquality()) {
					p = new Apfloat(1.0, PRECISION);
				} else {
					
					if (pc == null) {
						if (debugMode) System.out.println("!!!pc is null!!!!");
						p = new Apfloat(1.0, PRECISION);
					} else {
						p = conditionalMap.get(pc.header.stringPC());
						if (p == null) {
							if (debugMode) System.out.println("prob not found in store ");						
							p = calcProbability(pc);
						}
						else {
							if (debugMode) System.out.println("from store prob = " + p);	
						}
					}
					
				}
				if (!desc.contains(""+pc.header)) {
					if (debugMode) {
						System.out.println("desc so far " + desc);
						System.out.println("ppc = " + pc.header);
					}
					desc += pc.header;
				}
				pr = pr.multiply(p);
			}
			else if (cg instanceof HeapChoiceGenerator) {				
				HeapChoiceGenerator hcg = (HeapChoiceGenerator)cg;
				int choices = hcg.getTotalNumberOfChoices();
				int currentChoice = hcg.getNextChoice();
				if (choices == 2) { // only null and new, then use newProb=1-nullProb 
					if (currentChoice == 0) {
						p = nullProb;
					} else { // currentChoice == 1
						p = Apfloat.ONE.subtract(nullProb);
					}
				} else if (choices > 2) {
					if (currentChoice == 0) {
						p = nullProb;
					} else if (currentChoice == 1){
						p = newProb;
					} else { // 2 or more
						Apfloat aliasProb = Apfloat.ONE.subtract(nullProb).subtract(newProb);
						p = aliasProb.divide(new Apfloat(choices - 2,PRECISION));
					}
					
				} else {
					p = Apfloat.ONE.divide(new Apfloat(choices, PRECISION));
				}
				if (debugMode) {
					System.out.println("Found  Heap CG " + (HeapChoiceGenerator)cg);
					System.out.println("prop (" + choices + ") = " + p);
				}
				pr = pr.multiply(p);
				desc += hcg;
			}
			else if (cg instanceof IntIntervalGenerator) {
				int choices = cg.getTotalNumberOfChoices();
				p = Apfloat.ONE.divide(new Apfloat(choices, PRECISION)); 
				if (debugMode) {
					System.out.println("Found Int CG " + (IntIntervalGenerator)cg);
					System.out.println("prop (" + choices + ") = " + p);
				}
				pr = pr.multiply(p);
				desc += (IntIntervalGenerator)cg;
			}
			else if (cg instanceof ThreadChoiceFromSet) {
				int choices = cg.getTotalNumberOfChoices();
				p = Apfloat.ONE.divide(new Apfloat(choices, PRECISION)); 
				if (debugMode) {
					System.out.println("Found Scheduling CG " + (ThreadChoiceFromSet)cg);
					System.out.println("prop (" + choices + ") = " + p);
				}
				pr = pr.multiply(p);
				desc += (ThreadChoiceFromSet)cg;
			}
			else if (cg instanceof BooleanChoiceGenerator) {
				
				int choices = cg.getTotalNumberOfChoices();
				p = Apfloat.ONE.divide(new Apfloat(choices, PRECISION)); 
				if (debugMode) {
					System.out.println("Found Boolean CG " + (BooleanChoiceGenerator)cg);
					System.out.println("prop (" + choices + ") = " + p);
				}
				pr = pr.multiply(p);
				desc += (BooleanChoiceGenerator)cg;
			}
			else {
				System.out.println("Cannot Calculate Probability: Found unknown CG " + cg);
			}
			cg = cg.getPreviousChoiceGenerator();
		}
		if (debugMode) {
			System.out.println("Description = " + desc);
			System.out.println("Final probability = " + String.format("%.10s", pr));
		}
		return new ProbReturn(desc,pr);
	}
		
	private Apfloat calcProbability(PathCondition pc) {
		Apfloat p = conditionalMap.get(pc.header.stringPC());
		if (p != null) {
			//already did this one before
			return p;
		}
		if (pc != null) {
			calcMinPC(pc); 
			//totalConstraints += pc.count();
			//totalMinConstraints += minimalPC.count();
			p = getConditionalProbability(minimalPC, prior);
			conditionalMap.put(pc.header.stringPC(), p);			
			// now add the 1-p probability for the other branch to the conditionalMap
			Constraint negHead = pc.header.not();
			PathCondition notPC = pc.make_copy();
			notPC.removeHeader();
			notPC.prependUnlessRepeated(negHead);
			if (p.compareTo(Apfloat.ONE) == 0) {
				conditionalMap.put(notPC.header.stringPC(), new Apfloat(delta, PRECISION));
			} else {
				conditionalMap.put(notPC.header.stringPC(), new Apfloat(1.0, PRECISION).subtract(p));
			}
		}
		return p;
	}
	
	private Apfloat getConditionalProbability(PathCondition minimalPC, Apfloat prior) {
		Apfloat pr = new Apfloat(0.5, PRECISION); // default guess
		for (ModelCounter m : modelCounters) {
			Map<String, Apfloat> c = cache.get(m);
			//String x = minimalPC.toString().replaceAll("\n", " ").replaceAll("_[0-9][0-9]*_SYMINT", "").replaceAll("CONST_", "");
			if (!c.containsKey(minimalPC.header.stringPC())) {
				pr = m.getConditionalProbability(minimalPC, prior);
				c.put(minimalPC.header.stringPC(), pr);
			} else {
				pr = c.get(minimalPC.header.stringPC());
			}
		}
		return pr;
	}
	
	/**
	 * Find and return the path condition for the current state.
	 * 
	 * @param vm
	 *            the current JPF virtual machine
	 * @return the path condition
	 */
	private static PathCondition getPC(JVM vm) {
		ChoiceGenerator<?> cg = vm.getChoiceGenerator();
		while (cg != null) {
			if (cg instanceof PCChoiceGenerator) {
				return ((PCChoiceGenerator) cg).getCurrentPC();
			}
			cg = cg.getPreviousChoiceGenerator();
		}
		return null;
	}

	/**
	 * Given a path condition, calculate the minimal path condition and its
	 * prior probability, and store them in {@link #minimalPC} and
	 * {@link #prior}, respectively.
	 * 
	 * @param pc
	 *            the current path condition
	 */
	private void calcMinPC(PathCondition pc) {
		// compute the "prior" probability
		PathCondition tmpPC = pc.make_copy();
		Set<Constraint> minConstraints = DependencyCalc.calcMinConstraints(tmpPC);
		tmpPC.removeHeader();
		prior = new Apfloat(1.0, PRECISION);
		while (tmpPC.header != null) {
			if (minConstraints.contains(tmpPC.header)) {
				assert conditionalMap.containsKey(tmpPC.header.stringPC());
				prior = prior.multiply(conditionalMap.get(tmpPC.header.stringPC()));
			}
			tmpPC.removeHeader();
		}

		// ok, now we construct the minimal PC
		tmpPC = pc.make_copy();
		minimalPC = new PathCondition();
		minimalPC.header = DependencyCalc.copyConstraint(tmpPC.header);
		Constraint c = minimalPC.header;
		for (Constraint d = tmpPC.header.and; d != null; d = d.getTail()) {
			if (minConstraints.contains(d)) {
				c.and = DependencyCalc.copyConstraint(d);
				c = c.and;
			}
		}
		minimalPC.recomputeCount();
		minimalPC.resetHashCode();
		// END comment from here for slicing off
	}
	
	/**
	 * Compute the number of instructions of a path
	 * @param vm
	 * @return
	 */
	private long computeInstructions(JVM vm) {
		ThreadInfo ti = vm.getCurrentThread();
		return transitionStartInstructions + ti.getExecutedInstructions();
	}

}