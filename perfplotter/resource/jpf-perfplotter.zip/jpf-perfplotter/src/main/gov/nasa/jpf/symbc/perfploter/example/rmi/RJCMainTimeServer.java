package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class RJCMainTimeServer {

	public static void main(String[] args) {
		try {
			LocateRegistry.createRegistry(1099);
			TimeInterface time = new RJCMain();
			Naming.rebind("gov.nasa.jpf.symbc.perfploter.example.rmi.RJCMainRMI.DoSample(in11_0_d,in11_1_d,in11_2_d,in12_0_d,in12_1_d,in12_2_d,in21_0_d,in21_1_d,in21_2_d,in22_0_d,in22_1_d,in22_2_d)", time);
			System.out.println("Time Server is ready.");
		} catch (RemoteException | MalformedURLException e) {
			e.printStackTrace();
		}
	}

}
