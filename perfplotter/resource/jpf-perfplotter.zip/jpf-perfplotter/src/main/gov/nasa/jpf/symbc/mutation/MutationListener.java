package gov.nasa.jpf.symbc.mutation;

import org.apache.bcel.classfile.JavaClass;

import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.classfile.ClassFile;
import gov.nasa.jpf.jvm.JVM;

public class MutationListener extends ListenerAdapter {

	private String target = null;

	private Mutater mutater = null;

	private JavaClass targetClass = null;

	private String modification = null;

	public MutationListener(String target, Mutater mutater,
			JavaClass targetClass) {
		this.target = target;
		this.mutater = mutater;
		this.targetClass = targetClass;
	}

	public String getModification() {
		return modification;
	}

	@Override
	public void loadClass(JVM vm, ClassFile cf) {
		if (cf.getRequestedTypeName().equals(target)) {
			JavaClass cl = mutater.jumbler(targetClass);
			modification = mutater.getModification();
			cf.setData(cl.getBytes());
		}
	}

}
