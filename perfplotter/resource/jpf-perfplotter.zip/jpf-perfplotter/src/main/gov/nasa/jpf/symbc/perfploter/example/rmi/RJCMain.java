package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.io.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import apollo.rjc;

public class RJCMain extends UnicastRemoteObject implements TimeInterface {

	private static final long serialVersionUID = 5027320950823190293L;
	
	protected rjc controller;
	protected String filename1, filename2; // 2 CSV files for this example

	public RJCMain() throws RemoteException {
		this.controller = new rjc();
		this.controller.Init2();
	}

	public RJCMain(String filename1, String filename2) throws RemoteException {
		this();
		this.filename1 = filename1;
		this.filename2 = filename2;
	}

	public void DoSim() {

		ArrayList<ArrayList<String>> cmdInputs = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> measInputs = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<Double>> cmdVars = new ArrayList<ArrayList<Double>>();
		ArrayList<ArrayList<Double>> measVars = new ArrayList<ArrayList<Double>>();

		try {
			File file1 = new File(this.filename1);
			File file2 = new File(this.filename2);

			FileInputStream fis1 = new FileInputStream(file1);
			FileInputStream fis2 = new FileInputStream(file2);

			BufferedReader br1 = new BufferedReader(new InputStreamReader(fis1));
			BufferedReader br2 = new BufferedReader(new InputStreamReader(fis2));
			String strLine;

			// Read File Line By Line
			while ((strLine = br1.readLine()) != null) {
				if (!strLine.isEmpty()) {
					String[] inputs = strLine.split(",");
					ArrayList<String> line = new ArrayList<String>();
					ArrayList<Double> dubLine = new ArrayList<Double>();
					for (int ix = 0; ix < inputs.length; ix++) {
						line.add(inputs[ix]);
						dubLine.add(Double.parseDouble(inputs[ix]));
					}
					cmdInputs.add(line);
					cmdVars.add(dubLine);
				}
			}

			while ((strLine = br2.readLine()) != null) {
				if (!strLine.isEmpty()) {
					String[] inputs = strLine.split(",");
					ArrayList<String> line = new ArrayList<String>();
					ArrayList<Double> dubLine = new ArrayList<Double>();
					for (int ix = 0; ix < inputs.length; ix++) {
						line.add(inputs[ix]);
						dubLine.add(Double.parseDouble(inputs[ix]));
					}
					measInputs.add(line);
					measVars.add(dubLine);
				}
			}

			fis1.close();
			fis2.close();

			BufferedWriter out = new BufferedWriter(new FileWriter("JavaOutput.csv")); // Write the second output to a file

			for (int i = 0; i < cmdInputs.size() && i < measInputs.size(); i++) {
				ArrayList<Double> currCmd = cmdVars.get(i);
				ArrayList<Double> currMeas = measVars.get(i);
				// For now assume they are the correct size
				double[] output1 = new double[1];
				double[] output2 = new double[2];
				double[] input1 = new double[3];
				double[] input2 = new double[3];
				for (int j = 0; j < 3; j++) {
					input1[j] = currCmd.get(j + 1); // Throw away the time stamp
					input2[j] = currMeas.get(j + 1); // Throw away the time stamp
				}
				this.controller.Main0(input1, input2, output1, output2);

				System.out.println("Output 1 (yaw jets)   : " + output1[0]);
				System.out.println("Output 2 (pitch jets) : " + output2[0] + ", " + output2[1]);
				out.write("" + currCmd.get(0) + "," + output2[0] + "," + output2[1] + "\n");
			}

			out.close();

		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	// Symbolic pathfinder cannot handle arrays, so use this method if you want to run the process symbolically
	public void DoSimSymbolic() {
		double[] out1;
		double[] out2;

		out1 = new double[1];
		out2 = new double[2];
		this.controller.MainSymbolic1(0, 0, 0, 0, 0, 0, out1, out2);
		
		out1 = new double[1];
		out2 = new double[2];
		this.controller.MainSymbolic2(0, 0, 0, 0, 0, 0, out1, out2);
	}
	
	public void DoSample(double in11_0, double in11_1, double in11_2, double in12_0, double in12_1, double in12_2,
			double in21_0, double in21_1, double in21_2, double in22_0, double in22_1, double in22_2) {
		double[] out1;
		double[] out2;

		out1 = new double[1];
		out2 = new double[2];
		this.controller.MainSymbolic1(in11_0, in11_1, in11_2, in12_0, in12_1, in12_2, out1, out2);
		
		out1 = new double[1];
		out2 = new double[2];
		this.controller.MainSymbolic2(in21_0, in21_1, in21_2, in22_0, in22_1, in22_2, out1, out2);
	}

	public static void main(String[] args) throws RemoteException {
		RJCMain rjcmain;
		if (args.length < 2) { // Run symbolically if no args
			rjcmain = new RJCMain();
			rjcmain.DoSimSymbolic();
		}
		else {
			rjcmain = new RJCMain(args[0], args[1]);
			rjcmain.DoSim();
		}
	}

	@Override
	public long measureExecutionTime(Object[] argsValues) throws RemoteException {
		RJCMain rjc = new RJCMain();
		long start = System.nanoTime();
		rjc.DoSample((double)argsValues[0], (double)argsValues[1], (double)argsValues[2], 
				(double)argsValues[3], (double)argsValues[4], (double)argsValues[5],
				(double)argsValues[6], (double)argsValues[7], (double)argsValues[8], 
				(double)argsValues[9], (double)argsValues[10], (double)argsValues[11]);
		return System.nanoTime() - start;
	}
}
