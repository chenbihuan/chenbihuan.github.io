//
// Copyright (C) 2006 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
// 
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
// 
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.symbc.perfploter;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.search.Search;
import gov.nasa.jpf.symbc.numeric.PathCondition;
import gov.nasa.jpf.symbc.perfploter.example.rmi.*;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Stack;

import za.ac.sun.cs.solver.expr.Variable;

public class PerfPloterHeuristicSearch extends Search {
  
	private PerfPloterHeuristicState parentState;
	private Set<PerfPloterHeuristicState> childStates;
		
	private PathCondition pathCondition = null;
	private double pathProbability = 0;
	private long pathDiversity = 0;
	private long pathInstruction = 0;
	
	private String branchIfInfo = null;
	private int nBreakOut = 0;

	private int phase = 1;
	
	private Set<PerfPloterHeuristicState> toBeExploredStatesC;
	
	private List<List<PerfPloterHeuristicState>> toBeExploredStatesL;
	private Stack<String> loopIfInstructionStack = null;
	
	private Set<PerfPloterHeuristicState> unexploredStates;
	
	private double max_probability = 0;
	private double min_probability = 1;

	private long max_diversity = Long.MIN_VALUE;
	private long min_diversity = Long.MAX_VALUE;
	private double alpha = 0.5;
	
	private long max_instruction = Long.MIN_VALUE;
	private long min_instruction = Long.MAX_VALUE;
	private double beta = 0.5;
	private double gamma = 0.5;
	
	// stopping criterion for the first phase
	private double coverageProb = 0.4;
	
	// stopping criterion for the second phase
	private int consecutivePaths = 100;
	private int consecutiveSteps = 10;
	private int consecutivePathsTemp = consecutiveSteps;

	// skip interval of the systematic strategy for choose loop-related paths
	private int skipInterval = 1;
	
	// sample size when running the program to measure the execution time
	private int sampleSize = 10;
		
	private SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss.SSS");
	
	public PerfPloterHeuristicSearch(Config conf, JVM vm) {
		super(conf, vm);
	}
  
	public void search() {
		System.out.println(format.format(new Date(System.currentTimeMillis())) + " ====================================================== Selective Exploration started \n");
		// stopping criterion for the first phase
		double covProb = 0;
		// stopping criterion for the second phase
		int conPath = 0;
		int numOfRestartState = 0;
		double max_exeTime = -Double.MAX_VALUE;
		double min_exeTime = Double.MAX_VALUE;
		// store the chosen states for further exploration
		List<PerfPloterHeuristicState> states = new ArrayList<PerfPloterHeuristicState>();

		done = false;
		notifySearchStarted();
		if (!hasPropertyTermination()) {
			generateChildren();
			while (!done) {
				parentState = getNextStateToContinue();
				if (parentState != null) {
					restoreState(parentState);
				}
				// find a non-end state to start the exploration of a new path
				boolean isEnd = true;
				while (parentState == null || (isEnd = isEndState()) || depth >= depthLimit) {
					if (parentState == null) {
						System.err.println("All branches are infeasible due to coral's uncerainty");
					} else if (parentState.getPathCondition() != null) {
						covProb += parentState.getPathProbability();
						long start = System.currentTimeMillis();
						ExecutionTime exeTime = measureExecutionTime(parentState.getPathCondition(), isEnd);
						//ExecutionTime exeTime = new ExecutionTime(); exeTime.addTime(0);
						long end = System.currentTimeMillis();
						double mean = exeTime.getMean();
						double variance = exeTime.getVariance();
						System.out.print(format.format(new Date(System.currentTimeMillis())));
						System.out.println(" ***Path explored (" + isEnd + ") , pc = " + parentState.getPathCondition().header.stringPC() + ", prob = "
								+ parentState.getPathProbability() + " (" + covProb + "), mean = " + mean + ", variance = " + variance + " ("
								+ exeTime.getTimes().size() + "), SampleTime = " + (end - start));
						if (max_exeTime == -Double.MAX_VALUE && min_exeTime == Double.MAX_VALUE) {
							max_exeTime = mean;
							min_exeTime = mean;
						}  else if (mean > max_exeTime) {
							max_exeTime = mean;
							if (phase == 2 && numOfRestartState > 0) {
								numOfRestartState--;
								System.out.println("### Decrease " + numOfRestartState);
								conPath = 0;
							}
						} else if (mean < min_exeTime) {
							min_exeTime = mean;
							if (phase == 2 && numOfRestartState > 0) {
								numOfRestartState--;
								System.out.println("### Decrease " + numOfRestartState);
								conPath = 0;
							}
						} else {
							if (phase == 2 && numOfRestartState > 0) {
								numOfRestartState--;
								System.out.println("### Decrease " + numOfRestartState);
								conPath++;
							}
						}
						System.out.println("### " + conPath + ", max = " + max_exeTime + ", min = " + min_exeTime + "\n");
					} else { // there are no branch nodes
						covProb += 1.0;
						long start = System.currentTimeMillis();
						ExecutionTime exeTime = measureExecutionTime(null, true);
						//ExecutionTime exeTime = new ExecutionTime(); exeTime.addTime(0);
						long end = System.currentTimeMillis();
						System.out.print(format.format(new Date(System.currentTimeMillis())));
						System.out.println(" ***Path explored, pc = true, prob = 1.0 (" + covProb + "), mean = " + exeTime.getMean() + ", variance = " + exeTime.getVariance()
								+ " (" + exeTime.getTimes().size() + "), SampleTime = " + (end - start) + "\n");
					}
					if ((parentState == null || (!isEnd && depth >= depthLimit)) && loopIfInstructionStack != null) {
						loopIfInstructionStack.clear();
						System.out.println("Clear " + loopIfInstructionStack);
					}
					// first continue explore loop-related paths if exist
					if (toBeExploredStatesL != null) {
						// choose loop-related states and store other loop-related states
						for (List<PerfPloterHeuristicState> ls : toBeExploredStatesL) {
							System.out.println("Start");
							for(PerfPloterHeuristicState s : ls) {
								System.out.println(s.toString());
							}
							System.out.println("End");
						}
						List<PerfPloterHeuristicState> ss = getNextStatesForLoops();						
						for(PerfPloterHeuristicState s : ss) {
							System.out.println(s.toString());
						}
						if(ss.size() != 0) {
							System.out.println("\n");
						}
						states.addAll(ss);
						toBeExploredStatesL.clear();
					}
					// then continue explore non-loop-related paths if exist
					if (states.size() == 0) {
						// check if switch to the second phase or terminate
						if (phase == 1 && covProb >= coverageProb) {
							phase = 2;
							System.out.println(format.format(new Date(System.currentTimeMillis())) + " ====================================================== Phase 1 finished \n");						
						} else if (phase == 2 && conPath >= consecutivePathsTemp) {
							System.out.println(format.format(new Date(System.currentTimeMillis())) + " ====================================================== Phase 2 finished " + consecutivePathsTemp + "\n");
							consecutivePathsTemp += consecutiveSteps;
							if (phase == 2 && conPath >= consecutivePaths) {
								phase = 3;
							}
						}
						List<PerfPloterHeuristicState> ns = getNextStateToRestart();
						states.addAll(ns);
						if (phase == 2) {
							numOfRestartState = ns.size();
							System.out.println("### Set " + numOfRestartState + "\n");
						}
						if (phase == 3) {
							if (toBeExploredStatesC != null && toBeExploredStatesC.size() > 0) {
								if (unexploredStates == null) {
									unexploredStates = new HashSet<PerfPloterHeuristicState>();
								}
								unexploredStates.addAll(toBeExploredStatesC);
							}
						}
					}
					if (states.size() > 0) {
						parentState = states.get(0);
						states.remove(0);
						restoreState(parentState);
					} else {
						System.out.println(format.format(new Date(System.currentTimeMillis())) + " ====================================================== Selective Exploration finished \n");
						done = true;
						break;
					}
				}
				if (!isEnd && !(depth >= depthLimit)) {
					generateChildren();
				}
			}
			
			//explore the unexplored paths for an exhaustive search
			done = false;
			if (unexploredStates != null && unexploredStates.size() > 0) {
				double unCovProb = 0;
				for(PerfPloterHeuristicState s : unexploredStates) {
					System.out.println(s.toString());
				}
				System.out.println("\n");
				parentState = unexploredStates.iterator().next();
				unexploredStates.remove(parentState);
				do {
					if (parentState != null) {
						restoreState(parentState);
					}
					boolean isEnd = true;
					while (parentState == null || (isEnd = isEndState()) || depth >= depthLimit) {
						if (parentState == null) {
							System.err.println("All branches are infeasible due to coral's uncerainty");
						} else if (parentState != null) {
							long start = System.currentTimeMillis();
							ExecutionTime exeTime = measureExecutionTime(parentState.getPathCondition(), isEnd);
							//ExecutionTime exeTime = new ExecutionTime(); exeTime.addTime(0);
							long end = System.currentTimeMillis();
							double mean = exeTime.getMean();
							double variance = exeTime.getVariance();
							unCovProb += parentState.getPathProbability();
							System.out.print(format.format(new Date(System.currentTimeMillis())));
							System.out.println(" *****Path explored (" + isEnd + ") , pc = " + parentState.getPathCondition().header.stringPC() + ", prob = "
									+ parentState.getPathProbability() + " (" + unCovProb + "), mean = " + mean + ", variance = " + variance
									+ " (" + exeTime.getTimes().size() + "), SampleTime = " + (end - start) + "\n");
						}
						if (unexploredStates.size() > 0) {
							// random exploration
							/*int c = new java.util.Random().nextInt(unexploredStates.size());
							Iterator<PerfPloterHeuristicState> iterator = unexploredStates.iterator();
							for (int i = 0; i < c; i++) {
								iterator.next();
							}
							parentState = iterator.next();*/
							
							// exhaustive exploration
							parentState = unexploredStates.iterator().next();
							
							unexploredStates.remove(parentState);
							restoreState(parentState);
						} else {
							done = true;
							break;
						}
					}
					if (!isEnd && !(depth >= depthLimit)) {
						generateChildren();
					}
					parentState = getNextUnexploredState();
				} while (!done);
			}
			System.out.println(format.format(new Date(System.currentTimeMillis())) + " ====================================================== Exhaustive Exploration finished \n");
		}
		notifySearchFinished();
	}
	
	public boolean supportsBacktrack() {
		// we don't do multi-level backtracks, but automatically do backtrackToParent()
		// after each child state generation
		return false;
	}
	
	/*
	 * generate the set of all child states for the current parent state
	 * 
	 * overriding methods can use the return value to determine if they
	 * have to process the childStates, e.g. to compute priorities
	 * that require the whole set
	 * 
	 * @returns false if this is cut short by a property termination or
	 * explicit termination request
	 */
	protected boolean generateChildren() {
		while (!done) {
			if (!forward()) {
				notifyStateProcessed();
				return true;
			}
			depth++;
			notifyStateAdvanced();
			// note that we don't store the error state anymore, which means we
			// might encounter it along different paths. However, this is probably
			// what we want for search.multiple_errors.   
			if (currentError != null){
				notifyPropertyViolated();
				if (hasPropertyTermination()) {
					return false;
				}
			} else if (!isIgnoredState() && isNewState()) {
				PerfPloterHeuristicState newState = new PerfPloterHeuristicState(vm, pathCondition, pathProbability, pathDiversity, pathInstruction, branchIfInfo, nBreakOut);
				setBranchIfInfo(null);
				setNBreakOut(null);
				if (childStates == null) {
					childStates = new HashSet<PerfPloterHeuristicState>();
				}
				childStates.add(newState);
				notifyStateStored();
			}
			backtrackToParent();
		}
		return false;
	}

	private void backtrackToParent() {
		backtrack();
		depth--;
		notifyStateBacktracked();    
	}
  
	private void restoreState(PerfPloterHeuristicState state) {    
		vm.restoreState(state.getVMState());
		depth = vm.getPathLength();
		notifyStateRestored();
	}
	
	// choose a state to continue the exploration of one path
	private PerfPloterHeuristicState getNextStateToContinue() {
		// random se
		/*if (phase == 3) {
			PerfPloterHeuristicState state = null;
			if (childStates != null && childStates.size() > 0) {
				int item = new Random().nextInt(childStates.size());
				Iterator<PerfPloterHeuristicState> iterator = childStates.iterator();
				for (int i = 0; i < item; i++) {
					iterator.next();
				}
				state = iterator.next();
				childStates.remove(state);
				if (childStates.size() > 0) {
					if (toBeExploredStatesC == null) {
						toBeExploredStatesC = new HashSet<PerfPloterHeuristicState>();
					}
					toBeExploredStatesC.addAll(childStates);
					childStates.clear();
				}
			}
			return state;
		}*/
		// end of random se
		
		PerfPloterHeuristicState state = null;
		if (childStates == null || childStates.size() == 0) {
			return null;
		} else if (childStates.size() == 1) {
			state = childStates.iterator().next();
			String loopInfo = state.getBranchIfInfo();
			if (loopInfo != null && loopInfo.contains("JUMPBACK")) {
				// if a new input-dependent loop is encountered
				if (loopIfInstructionStack == null || loopIfInstructionStack.size() == 0) {
					if (toBeExploredStatesL == null) {
						toBeExploredStatesL = new ArrayList<List<PerfPloterHeuristicState>>();
					}
					toBeExploredStatesL.add(new ArrayList<PerfPloterHeuristicState>());
				}
				push(loopInfo);
			} else if (loopInfo != null && loopInfo.contains("BREAKOUT")) {
				pop();
			}
			for (int i = 0; i < state.getnBreakOut(); i++) {
				pop();
			}
			childStates.clear();
			return state;
		}

		// always take the true branch if it is from a loop or take the non-break branch if it is a break condition in a loop
		boolean hasBreak = false;
		boolean hasJump = false;
		for (PerfPloterHeuristicState s : childStates) {
			String loopInfo = s.getBranchIfInfo();
			if (loopInfo != null && loopInfo.contains("BREAKOUT")) {
				hasBreak = true;
			} else if (loopInfo != null && loopInfo.contains("JUMPBACK")) {
				hasJump = true;
			}
		}
		if (hasBreak || hasJump) {
			for (PerfPloterHeuristicState s : childStates) {
				String loopInfo = s.getBranchIfInfo();
				if (loopInfo.contains("COMMON") && hasBreak) {
					state = s;
				} else if (loopInfo.contains("JUMPBACK")) {
					state = s;
					// if a new loop is encountered
					if (loopIfInstructionStack == null || loopIfInstructionStack.size() == 0) {
						if (toBeExploredStatesL == null) {
							toBeExploredStatesL = new ArrayList<List<PerfPloterHeuristicState>>();
						}
						toBeExploredStatesL.add(new ArrayList<PerfPloterHeuristicState>());
					}
					push(loopInfo);
				} else {
					continue;
				}
				for (int i = 0; i < state.getnBreakOut(); i++) {
					pop();
				}
				childStates.remove(state);
				toBeExploredStatesL.get(toBeExploredStatesL.size() - 1).addAll(childStates);
				childStates.clear();
				return state;
			}
		}
		
		// either take the high-probability or low-probability branch if it is from a conditional statement
		double prob;
		if (phase == 1) {
			prob = -Double.MAX_VALUE;
		} else {
			prob = Double.MAX_VALUE;
		}
		for (PerfPloterHeuristicState s : childStates) {
			if (phase == 1) {
				if (s.getPathProbability() > prob) {
					state = s;
					prob = s.getPathProbability();
				}
			} else {
				if (s.getPathProbability() < prob) {
					state = s;
					prob = s.getPathProbability();
				}
			}
		}
		for (int i = 0; i < state.getnBreakOut(); i++) {
			pop();
		}
		childStates.remove(state);
		if (toBeExploredStatesC == null) {
			toBeExploredStatesC = new HashSet<PerfPloterHeuristicState>();
		}
		toBeExploredStatesC.addAll(childStates);
		updateMaxMin(childStates);
		childStates.clear();
		return state;
	}
	
	// choose a state to start the exploration of a new path
	private List<PerfPloterHeuristicState> getNextStateToRestart() {
		double utility1;
		double utility2;
		PerfPloterHeuristicState state1 = null;
		PerfPloterHeuristicState state2 = null;
		List<PerfPloterHeuristicState> states = new ArrayList<PerfPloterHeuristicState>();
		
		if (toBeExploredStatesC != null) {
			if (phase == 1) {
				utility1 = -Double.MAX_VALUE;
				for (PerfPloterHeuristicState s : toBeExploredStatesC) {
					double u = computeF1(s);
					if (u > utility1) {
						utility1 = u;
						state1 = s;
					}
				}
				if (state1 != null) {
					toBeExploredStatesC.remove(state1);
					updateMaxMin(state1);
					states.add(state1);
					System.out.println("***P1 : " + state1 + "\n");
				}
			} else if (phase == 2){
				utility1 = Double.MAX_VALUE;
				utility2 = Double.MAX_VALUE;
				for (PerfPloterHeuristicState s : toBeExploredStatesC) {
					double u = computeF2(s);
					if (u < utility1) {
						utility1 = u;
						state1 = s;
					}
					u = computeF3(s);
					if (u <= utility2) {
						utility2 = u;
						state2 = s;
					}
				}
				if (state1 != null && state2 != null) {
					if (state1 == state2) {
						toBeExploredStatesC.remove(state1);
						updateMaxMin(state1);
						states.add(state1);
						System.out.println("***P21 : " + state1 + "\n");
					} else {
						toBeExploredStatesC.remove(state1);
						updateMaxMin(state1);
						toBeExploredStatesC.remove(state2);
						updateMaxMin(state2);
						states.add(state1);
						states.add(state2);
						System.out.println("***P22 : " + state1 + ", " + state2 + "\n");
					}
				}
			}
		}
		return states;
	}
	
	private List<PerfPloterHeuristicState> getNextStatesForLoops() {
		List<PerfPloterHeuristicState> states = new ArrayList<PerfPloterHeuristicState>();
		if (toBeExploredStatesL != null) {
			for(List<PerfPloterHeuristicState> ls : toBeExploredStatesL) {
				if (ls.size() > 0 && ls.size() <= 2) {
					states.addAll(ls);
				} else if (ls.size() >= 3) {
					PerfPloterHeuristicState s = ls.get(0);
					double p = s.getPathProbability();
					states.add(s);

					PerfPloterHeuristicState max_s = s;
					double max_p = p;
					int max_index = 0;
					
					PerfPloterHeuristicState min_s = s;
					double min_p = p;
					int min_index = 0;
					
					for (int i = 1; i < ls.size(); i++) {
						s = ls.get(i);
						p = s.getPathProbability();
						
						if (i % (skipInterval + 1) == 0) {
							states.add(s);
							if (p > max_p) {
								if (max_index % (skipInterval + 1) != 0) {
									if (unexploredStates == null) {
										unexploredStates = new HashSet<PerfPloterHeuristicState>();
									}
									unexploredStates.add(max_s);
								}
								max_s = s;
								max_p = p;
								max_index = i;
							} else if (p < min_p) {
								if (min_index % (skipInterval + 1) != 0) {
									if (unexploredStates == null) {
										unexploredStates = new HashSet<PerfPloterHeuristicState>();
									}
									unexploredStates.add(min_s);
								}
								min_s = s;
								min_p = p;
								min_index = i;
							}
						} else {
							if (p > max_p) {
								if(max_index % (skipInterval + 1) != 0) {
									if (unexploredStates == null) {
										unexploredStates = new HashSet<PerfPloterHeuristicState>();
									}
									unexploredStates.add(max_s);
								}
								max_s = s;
								max_p = p;
								max_index = i;
							} else if (p < min_p) {
								if(min_index % (skipInterval + 1) != 0) {
									if (unexploredStates == null) {
										unexploredStates = new HashSet<PerfPloterHeuristicState>();
									}
									unexploredStates.add(min_s);
								}
								min_s = s;
								min_p = p;
								min_index = i;
							} else {
								if (unexploredStates == null) {
									unexploredStates = new HashSet<PerfPloterHeuristicState>();
								}
								unexploredStates.add(s);
							}
						}
					}
					if (max_index % (skipInterval + 1) != 0) {
						states.add(max_s);
					}
					if (min_index % (skipInterval + 1) != 0) {
						states.add(min_s);
					}
				}
			}
		}
		return states;
	}
	
	private PerfPloterHeuristicState getNextUnexploredState() {
		PerfPloterHeuristicState state = null;
		if (childStates != null && childStates.size() > 0) {
			// random selection
			/*int c = new java.util.Random().nextInt(childStates.size());
			Iterator<PerfPloterHeuristicState> iterator = childStates.iterator();
			for (int i = 0; i < c; i++) {
				iterator.next();
			}
			state = iterator.next();*/
			
			// exhaustive selection
			state = childStates.iterator().next();
			
			childStates.remove(state);
			if (childStates.size() > 0) {
				unexploredStates.addAll(childStates);
				childStates.clear();
			}
		}
		return state;
	}
	
	// compute objective function 1 (the larger the better)
	private double computeF1(PerfPloterHeuristicState state) {
		double utility; 
		if (max_diversity == min_diversity) {
			utility = state.getPathProbability();
		} else if (max_probability == min_probability) {
			utility = max_diversity - state.getPathDiversity();
		} else {
			utility = alpha * (state.getPathProbability() - min_probability) / (max_probability - min_probability)
					+ (1.0 - alpha) * (max_diversity - state.getPathDiversity()) / (max_diversity - min_diversity);
		}
		return utility;
	}
	
	// compute objective function 2 (find best-case, the smaller the better)
	private double computeF2(PerfPloterHeuristicState state) {
		double utility; 
		if (max_instruction == min_instruction) {
			utility = state.getPathProbability();
		} else if (max_probability == min_probability) {
			utility = state.getPathInstruction();
		} else {
			utility = beta * (state.getPathProbability() - min_probability) / (max_probability - min_probability)
					+ (1.0 - beta) * (state.getPathInstruction() - min_instruction) / (max_instruction - min_instruction);
		}
		return utility;
	}
	
	// compute objective function 3 (find worst-case, the smaller the better)
	private double computeF3(PerfPloterHeuristicState state) {
		double utility; 
		if (max_instruction == min_instruction) {
			utility = state.getPathProbability();
		} else if (max_probability == min_probability) {
			utility = max_instruction - state.getPathInstruction();
		} else {
			utility = gamma * (state.getPathProbability() - min_probability) /(max_probability - min_probability)
					+ (1.0 - gamma) * (max_instruction - state.getPathInstruction()) / (max_instruction - min_instruction);
		}
		return utility;
	}

	// update max and min when unexplored states are added
	private void updateMaxMin(Set<PerfPloterHeuristicState> states) {
		for(PerfPloterHeuristicState s : states) {
			double p = s.getPathProbability();
			long d = s.getPathDiversity();
			long i = s.getPathInstruction();
			if (p > max_probability) {
				max_probability = p;
			}
			if (p < min_probability) {
				min_probability = p;
			}
			if (d > max_diversity) {
				max_diversity = d;
			}
			if (d < min_diversity) {
				min_diversity = d;
			}
			if (i > max_instruction) {
				max_instruction = i;
			}
			if ( i < min_instruction) {
				min_instruction = i;
			}
		}
	}
	
	// update max and min when an unexplored state is chosen
	private void updateMaxMin(PerfPloterHeuristicState state) {
		double p = state.getPathProbability();
		long d = state.getPathDiversity();
		long i = state.getPathInstruction();
		boolean flag = false;
		if (p == max_probability) {
			max_probability = 0;
			flag = true;
		}
		if (p == min_probability) {
			min_probability = 1;
			flag = true;
		}
		if (d == max_diversity) {
			max_diversity = Long.MIN_VALUE;
			flag = true;
		}
		if (d == min_diversity) {
			min_diversity = Long.MAX_VALUE;
			flag = true;
		}
		if (i == max_instruction) {
			max_instruction = Long.MIN_VALUE;
			flag = true;
		}
		if (i == min_instruction) {
			min_instruction = Long.MAX_VALUE;
			flag = true;
		}
		if (flag) {
			updateMaxMin(toBeExploredStatesC);
		}
	}
	
	private ExecutionTime measureExecutionTime(PathCondition pc, boolean isEnd) {
		String methodSignature = config.getString("sample.method");
		if (methodSignature == null) {
			System.err.println("sample method is not given in .jpf");
			System.exit(0);
		}
		String[] arguments = methodSignature.substring(methodSignature.lastIndexOf("(") + 1, methodSignature.lastIndexOf(")")).split(",");
		
		int minInt = config.getInt("symbolic.min_int", -1000000);
		int maxInt = config.getInt("symbolic.max_int", 1000000);
		double minDouble = config.getDouble("symbolic.min_double", -8);
		double maxDouble = config.getDouble("symbolic.max_double", 7);
		float minFloat = ((Double)minDouble).floatValue();
		float maxFloat = ((Double)maxDouble).floatValue();

		ExecutionTime exeTime = new ExecutionTime();
		List<HashMap<String, Object>> solutions = getSampleSolutions(pc, isEnd);
		
		try {
			TimeInterface time = (TimeInterface)Naming.lookup("rmi://172.21.241.38/" + methodSignature);
		
			int nSol = isEnd ? sampleSize : 2 * sampleSize;
			for (int i = 0; i < nSol; i++) {
				Object[] argsValues = new Object[arguments.length];
				int index = i < solutions.size() || solutions.size() == 0 ? i : new Random().nextInt(solutions.size());
				for (int j = 0; j < arguments.length; j++) {
					String argName = arguments[j].substring(0, arguments[j].lastIndexOf("_"));
					String argType = arguments[j].substring(arguments[j].lastIndexOf("_") + 1);
					Object value = solutions.size() == 0 ? null : solutions.get(index).get(argName);
					if (value != null) {
						if (argType.equals("b")) {
							argsValues[j] = ((int)value) != 0;
						} else if (argType.equals("i") || argType.equals("l")) {
							argsValues[j] = ((Integer)value).intValue();
						} else if (argType.equals("f")) {
							argsValues[j] = ((Double)value).floatValue();
						} else if (argType.equals("d")) {
							argsValues[j] = ((Double)value).doubleValue();
						} else {
							System.err.println("unsupported data type " + argType);
						}
					} else {
						System.out.println("Random input");
						if (argType.equals("b")) {
							argsValues[j] = new Random().nextBoolean();
						} else if (argType.equals("i") || argType.equals("l")) {
							argsValues[j] = new Random().nextInt(maxInt - minInt + 1) + minInt;
						} else if (argType.equals("f")) {
							argsValues[j] = new Random().nextFloat() * (maxFloat - minFloat) + minFloat;
						} else if (argType.equals("d")) {
							argsValues[j] = new Random().nextDouble() * (maxDouble - minDouble) + minDouble;
						}
					}
					System.out.println(argName + " : " + argsValues[j]);
				}
				/*double mean = time.measureExecutionTime(argsValues);
				if (mean < 2000000) {
					for (int j = 0; j < 1999; j++) {
						mean += time.measureExecutionTime(argsValues);
					}
					exeTime.addTime(mean / 2000);
				} else {
					exeTime.addTime(mean);
				}*/
				
				/*double mean = 0;
				for (int j = 0; j < 2000; j++) {
					mean += time.measureExecutionTime(argsValues);
				}
				exeTime.addTime(mean / 2000);*/
				
				exeTime.addTime(time.measureExecutionTime(argsValues));
			}
		} catch (RemoteException | MalformedURLException | NotBoundException e) {
			e.printStackTrace();
		}
		
		return exeTime;
	}
	
	private List<HashMap<String, Object>> getSampleSolutions(PathCondition pc, boolean isEnd) {
		int nSol = isEnd ? sampleSize : 2 * sampleSize;
		List<HashMap<String, Object>> solutions = new ArrayList<HashMap<String, Object>>();
		boolean hasNext = true;
		while (hasNext && solutions.size() < nSol) {
			if (pc != null) {
				HashMap<String, Object> solution;
				if (config.getString("symbolic.prob_modelcounter").contains("LattECounter")) {
					Set<Variable> vs = pc.getInstance().getAllVariables();
					Iterator<Variable> iterator = vs.iterator();
					solution = new HashMap<String, Object>();
					while (iterator.hasNext()) {
						Variable v = iterator.next();
						solution.put(v.getOriginal().toString().replaceAll("_[0-9][0-9]*_SYMINT", ""), pc.getInstance().getIntValue(v));
					}
					solutions.add(solution);
					hasNext = pc.getInstance().findNextVariableMap();
				} else if (config.getString("symbolic.prob_modelcounter").contains("QCoralCounter")) {
					solution = pc.getSolution();
					solutions.add(solution);
				} else {
					System.err.println("Unsupported model counter");
				}
			} else {
				hasNext = false;
			}
		}
		return solutions;
	}
	
	private void push(String info) {
		if (loopIfInstructionStack == null) {
			loopIfInstructionStack = new Stack<String>();
		}
		if (!loopIfInstructionStack.contains(info)) {
			loopIfInstructionStack.push(info);
			System.out.println("Push " + loopIfInstructionStack + "\n");
		}
	}
	
	private String pop() {
		String info = null;
		if (loopIfInstructionStack != null && loopIfInstructionStack.size() > 0) {
			info = loopIfInstructionStack.pop();
			System.out.println("Pop " + loopIfInstructionStack + "\n");
		}
		return info;
	}
	
	public void setPathCondition(PathCondition pathCondition) {
		this.pathCondition = pathCondition;
	}

	public void setPathProbability(double pathProbability) {
		this.pathProbability = pathProbability;
	}

	public void setPathDiversity(long pathDiversity) {
		this.pathDiversity = pathDiversity;
	}

	public void setPathInstruction(long pathInstruction) {
		this.pathInstruction = pathInstruction;
	}

	public String getBranchIfInfo() {
		return branchIfInfo;
	}

	public void setBranchIfInfo(String branchIfInfo) {
		this.branchIfInfo = branchIfInfo;
	}
	
	public void setNBreakOut(String ifInfo) {
		if (ifInfo == null) {
			this.nBreakOut = 0;
		} else if (ifInfo.contains("BREAKOUT")){
			this.nBreakOut++;
		}
	}
	
	public Stack<String> getLoopIfInstructionStack() {
		return loopIfInstructionStack;
	}
		
	class ExecutionTime {
		List<Double> times;
		
		public void addTime(double time) {
			if (times == null) {
				times = new ArrayList<Double>();
			}
			times.add(time);
		}
		
		public double getMean() {
			if (times != null) {
				double sum = 0;
				for(Double t : times) {
					sum += t;
				}
				return sum / times.size();
			} else {
				return 0;
			}
		}
		
		public double getVariance() {
			if (times != null) {
				double mean = getMean();
				double variance = 0;
				for (Double t : times) {
					variance += (t - mean) * (t - mean);
				}
				return variance / times.size();
			} else {
				return 0;
			}
		}

		public List<Double> getTimes() {
			return times;
		}
		
	}
	
}
