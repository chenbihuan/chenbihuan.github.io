package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class TSAFETimeClient {

	public static void main(String[] args) {
		try {
			TimeInterface time = (TimeInterface) Naming.lookup("rmi://172.21.241.198/gov.nasa.jpf.symbc.perfploter.example.rmi.TSAFE.TestDriver2(latitude1_d,longitude1_d,latitude2_d,longitude2_d)");
			Object[] argsValues = new Object[4];
			for (int i = 0; i < 4; i++) {
				argsValues[i] = (Math.random()) * 180 - 90;
			}
			System.out.println(time.measureExecutionTime(argsValues));
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			e.printStackTrace();
		}
	}

}
