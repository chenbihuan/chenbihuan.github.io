package gov.nasa.jpf.symbc.perfploter.example.rmi;

import immortal.persistentScope.transientScope.Motion;
import immortal.persistentScope.transientScope.Reducer;
import immortal.persistentScope.transientScope.Vector3d;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import javacp.util.LinkedList;

public class CDx extends UnicastRemoteObject implements TimeInterface {

	private static final long serialVersionUID = 7883291490097633104L;

	protected CDx() throws RemoteException {
		super();
	}
	
	@Override
	public long measureExecutionTime(Object[] argsValues) throws RemoteException {
		LinkedList motions = new LinkedList();
		for (int i = 0; i < 10; i++) {
			Vector3d sta = new Vector3d((float)argsValues[6 * i], (float)argsValues[6 * i + 1], (float)argsValues[6 * i + 2]);
			Vector3d end = new Vector3d((float)argsValues[6 * i + 3], (float)argsValues[6 * i + 4], (float)argsValues[6 * i + 5]);
			Motion motion = new Motion(null, sta, end);
			motions.add(motion);
		}
		long start = System.nanoTime();
		new Reducer(immortal.Constants.GOOD_VOXEL_SIZE).reduceCollisionSetSimplified(motions);
		return System.nanoTime() - start;
	}

}
