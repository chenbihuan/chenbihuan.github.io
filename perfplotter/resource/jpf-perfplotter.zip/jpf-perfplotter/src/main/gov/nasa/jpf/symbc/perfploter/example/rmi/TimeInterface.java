package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface TimeInterface extends Remote {

	public long measureExecutionTime(Object[] argsValues) throws RemoteException;
	
}