package gov.nasa.jpf.symbc.modelcounter.qcoral;

import java.io.FileNotFoundException;
import java.util.Set;

import org.apfloat.Apfloat;

import symlib.parser.ParseException;
import coral.PC;
import coral.counters.refactoring.Runner;
import gov.nasa.jpf.Config;
import gov.nasa.jpf.symbc.modelcounter.ModelCounter;
import gov.nasa.jpf.symbc.numeric.PathCondition;

public class QCoralCounter extends ModelCounter {
	
	/*
	 * APfloat precision is set here
	 */
	private static final int PRECISION = 500; 
	
	private static String profileFile;
	
	private double delta = 0.00001;
	public QCoralCounter(Config config) {
		super(config);
		profileFile = config.getString("symbolic.coral.profile");
	}

	@Override
	public Apfloat getConditionalProbability(PathCondition pathCondition, Apfloat parentProb) {
		PC pc = pathCondition.getCoralPC();
		Apfloat conditionalProb = Apfloat.ZERO;
		if (pc == null) {
			System.err.println("Path condition in Coral is null");
		} else {
			try {
				double prob = Runner.calculatePathProbability(profileFile, pc);
				if (prob == 0.0) {
					prob += delta;
				}
				if (parentProb.compareTo(Apfloat.ZERO) == 0) {
					parentProb = new Apfloat(delta, PRECISION);
					System.out.println("parent probability is zero!!!");
				}
				conditionalProb = new Apfloat(prob, PRECISION).divide(parentProb);
			} catch (FileNotFoundException | ParseException e) {
				e.printStackTrace();
			}
		}
		if (conditionalProb.compareTo(Apfloat.ZERO) < 0 && conditionalProb.compareTo(Apfloat.ONE) > 0) {
			System.err.println("condProb = " + conditionalProb + " parentProb = " + parentProb);
			conditionalProb = Apfloat.ONE;
		}
		return conditionalProb;
	}

	/**
	 * Calculate the probability of the disjunction of a set of pathCondition.
	 */
	@Override
	public Apfloat getProbability(Set<PathCondition> pathConditions) {
		return Apfloat.ONE;
	}

}
