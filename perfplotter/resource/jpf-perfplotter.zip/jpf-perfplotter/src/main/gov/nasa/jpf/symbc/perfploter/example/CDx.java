package gov.nasa.jpf.symbc.perfploter.example;

import gov.nasa.jpf.symbc.Debug;
import immortal.persistentScope.transientScope.Motion;
import immortal.persistentScope.transientScope.Reducer;
import immortal.persistentScope.transientScope.Vector3d;
import javacp.util.LinkedList;

public class CDx {

	public static void TestDriver() {
		LinkedList motions = new LinkedList();
		for (int i = 0; i < 10; i++) {
			Vector3d start = new Vector3d((float)Debug.makeSymbolicReal("ls"+i), (float)Debug.makeSymbolicReal("ws"+i), (float)Debug.makeSymbolicReal("hs"+i));
			Vector3d end = new Vector3d((float)Debug.makeSymbolicReal("le"+i), (float)Debug.makeSymbolicReal("we"+i), (float)Debug.makeSymbolicReal("he"+i));
			Motion motion = new Motion(null, start, end);
			motions.add(motion);
		}
		new Reducer(immortal.Constants.GOOD_VOXEL_SIZE).reduceCollisionSetSimplified(motions);
	}
	public static void main(String[] args) {
		TestDriver();
	}

}
