package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class QuickSort extends UnicastRemoteObject implements TimeInterface {

	protected QuickSort() throws RemoteException {
		super();
	}

	private static final long serialVersionUID = -4672676480185066916L;

	private int partition (int[] arr, int left, int right, int pivotIndex) {
        int pivotValue = arr[pivotIndex];
        {
            int t = arr[pivotIndex];
            arr[pivotIndex] = arr[right];
            arr[right] = t;
            try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (arr[i] <= pivotValue) {
                int t = arr[i];
                arr[i] = arr[storeIndex];
                arr[storeIndex] = t;
                storeIndex++;
                try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
            }
        }
        {
            int t = arr[storeIndex];
            arr[storeIndex] = arr[right];
            arr[right] = t;
            try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
        return storeIndex;
    }

    private void quicksort (int[] arr, int left, int right) {
        if (right > left) {            
            int pivotIndex = left + (right - left) / 2;
            int pivotNewIndex = partition(arr, left, right, pivotIndex);
            quicksort(arr, left, pivotNewIndex - 1);
            quicksort(arr, pivotNewIndex + 1, right);
        }
    }

    public void doit6(int v1, int v2, int v3, int v4, int v5, int v6) {
    	int[] data = new int[6];
    	data[0] = v1;
    	data[1] = v2;
    	data[2] = v3;
    	data[3] = v4;
    	data[4] = v5;
    	data[5] = v6;
    	quicksort(data, 0, data.length - 1);
    }
    
    public void doit7(int v1, int v2, int v3, int v4, int v5, int v6, int v7) {
    	int[] data = new int[7];
    	data[0] = v1;
    	data[1] = v2;
    	data[2] = v3;
    	data[3] = v4;
    	data[4] = v5;
    	data[5] = v6;
    	data[6] = v7;
    	quicksort(data, 0, data.length - 1);
    }
    
    @Override
	public long measureExecutionTime(Object[] argsValues) throws RemoteException {
    	long start = System.currentTimeMillis();
    	//doit6((int)argsValues[0], (int)argsValues[1], (int)argsValues[2], (int)argsValues[3], (int)argsValues[4], (int)argsValues[5]);
    	doit7((int)argsValues[0], (int)argsValues[1], (int)argsValues[2], (int)argsValues[3], (int)argsValues[4], (int)argsValues[5], (int)argsValues[6]);
    	return System.currentTimeMillis() - start;
	}

}
