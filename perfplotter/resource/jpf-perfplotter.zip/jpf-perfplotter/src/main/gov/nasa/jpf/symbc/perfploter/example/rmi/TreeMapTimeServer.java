package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class TreeMapTimeServer {

	public static void main(String[] args) {
		try {
			LocateRegistry.createRegistry(1099);
			TimeInterface time = new TreeMap();
			Naming.rebind("gov.nasa.jpf.symbc.perfploter.example.TreeMap.runTest(c0_i,c1_i,c2_i,c3_i,c4_i,v5_i,v6_i,v7_i,v8_i,v9_i)", time);
			System.out.println("Time Server is ready.");
		} catch (RemoteException | MalformedURLException e) {
			e.printStackTrace();
		}
	}

}
