package gov.nasa.jpf.symbc.perfploter.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class RJCMainTimeClient {

	public static void main(String[] args) {
		try {
			TimeInterface time = (TimeInterface) Naming.lookup("rmi://172.21.241.38/gov.nasa.jpf.symbc.perfploter.example.rmi.RJCMainRMI.DoSample(in11_0_d,in11_1_d,in11_2_d,in12_0_d,in12_1_d,in12_2_d,in21_0_d,in21_1_d,in21_2_d,in22_0_d,in22_1_d,in22_2_d)");
			Object[] argsValues = new Object[12];
			argsValues[0] = 100.0;
			argsValues[1] = 100.0;
			argsValues[2] = 100.0;
			argsValues[3] = 100.0;
			argsValues[4] = 100.0;
			argsValues[5] = 100.0;
			argsValues[6] = 100.0;
			argsValues[7] = 100.0;
			argsValues[8] = 100.0;
			argsValues[9] = 100.0;
			argsValues[10] = 100.0;
			argsValues[11] = 100.0;
			for (int k = 0; k < 10; k++) {
				double mean = 0;
				for (int j = 0; j < 10; j++) {
					double sum = 0;
					for (int i = 0; i < 2000; i++) {
						sum += time.measureExecutionTime(argsValues);
					}
					mean += sum / 2000;
				}
				System.out.println(mean / 10);
			}
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			e.printStackTrace();
		}
	}

}
