package probsym.concurrent;

import java.util.concurrent.BrokenBarrierException;

public class SmallConcurrentTestDriver {

	public static void main(String[] args) {
		int i = 100;
		
		int totalOne = 0;
		int totalTwo = 0;
		
		while (i-- > 0) {
			SmallConcurrentTest sct = new SmallConcurrentTest();
			try {
				sct.startit();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BrokenBarrierException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int res = sct.getResult(); 
			if (res == 1)
				totalOne++;
			else 
				totalTwo++;
		}
		System.out.println("One = " + totalOne);
		System.out.println("Two = " + totalTwo);
	}

}
