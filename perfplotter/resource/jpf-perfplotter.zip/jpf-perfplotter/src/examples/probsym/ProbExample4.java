package probsym;
import gov.nasa.jpf.symbc.probsym.Analyze;

/**
 * Probabilistic symbolic execution.
 * 
 * Complex example with many strange operations.
 */
public class ProbExample4 {

	
	public static void covered(int br) {
		Analyze.coverage(""+br);
	}

	public static void test(int x, int y, int z) {
		/*
		int n = 0;
		while ((x > z) && (n++ < 2)) {
			y = y + z;
			z = y - z;
			y = y - z;
			x = x - y + 1;
		}
		
		if (x==y) {
			z = 0;
		}
		*/
		
		if (y < 5) {
			x = y;
			covered(1);
		}
		
		if (y == 0) {
			x = 1;
			covered(2);
		}
		if (z == y) {
			z = 1;
			covered(3);
		}
		
	}

	public static void main(String[] args) {
		test(20, 10, 5);
	}


}
