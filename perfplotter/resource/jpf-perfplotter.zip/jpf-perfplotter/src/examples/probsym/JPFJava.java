package probsym;
import gov.nasa.jpf.*;

public class JPFJava {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* this works bit it is not that useful
		String[] jpfArgs = { "src/examples/probsym/BinomialHeap.jpf" };
        Config conf = JPF.createConfig( jpfArgs );
        JPF jpf = new JPF(conf);
        jpf.run();
        */
		
		try {

			/*
			 This is what we would like to see happen below
			 
			 target=probsym.BinomialHeapBug
			 classpath=${jpf-symbc}/build/examples;${jpf-symbc}/build/main
			 sourcepath=${jpf-symbc}/src/examples
			 symbolic.method=probsym.BinomialHeapBug.runTestDriver(con);
			 symbolic.persistence = .symbc.persistence.PersistentJedis
			 symbolic.dp = cvc3

			 symbolic.prob_modelcounter=.symbc.modelcounter.latte.LattECounter
			 symbolic.prob_tool_counter=lib/count.osx
			 
			 listener = .symbc.probsym.ProbSymListener
			 symbolic.prob_min_int = 0
			 symbolic.prob_max_int = 9

			 symbolic.prob_min_int_c0 = 1
			 symbolic.prob_max_int_c0 = 2
			 ...
			 symbolic.prob_min_int_c7 = 1
			 symbolic.prob_max_int_c7 = 2
			 
			 vm.storage.class=nil
			 */
			
		      // this initializes the JPF configuration from default.properties, site.properties
		      // configured extensions (jpf.properties), current directory (jpf.properies) and
		      // command line args ("+<key>=<value>" options and *.jpf)
		      Config conf = JPF.createConfig(args);

		      // now set all the properties
		      conf.setProperty("target", "probsym.BinomialHeapBug");
		      conf.setProperty("classpath", "${jpf-symbc}/build/examples;${jpf-symbc}/build/main");
		      conf.setProperty("sourcepath", "${jpf-symbc}/src/examples");
		      conf.setProperty("symbolic.method","probsym.BinomialHeapBug.runTestDriver(con);");
		      conf.setProperty("symbolic.persistence", ".symbc.persistence.PersistentJedis");
		      conf.setProperty("symbolic.dp", "cvc3");
		      conf.setProperty("symbolic.prob_modelcounter", ".symbc.modelcounter.latte.LattECounter");
		      conf.setProperty("symbolic.prob_tool_counter", "lib/count.osx");
		      // sets the listener as a property not explicitly as in the commented out code below
		      conf.setProperty("listener", ".symbc.probsym.ProbSymListener");
		      
		      conf.setProperty("symbolic.prob_min_int", "0");
		      conf.setProperty("symbolic.prob_max_int", "9");
		      conf.setProperty("vm.storage.class", "nil");
		      
		      for(int i = 0; i < 10; i++) {
		    	  conf.setProperty("symbolic.prob_min_int_c"+i, "1");
		    	  conf.setProperty("symbolic.prob_max_int_c"+i, "2");
		      }
		      
		      // ... explicitly create listeners (could be reused over multiple JPF runs)
		      //MyListener myListener = 

		      JPF jpf = new JPF(conf);

		      // ... set your listeners
		      //jpf.addListener(myListener);

		      jpf.run();
		      if (jpf.foundErrors()){
		        // ... process property violations discovered by JPF
		      }
		    } catch (JPFConfigException cx){
		      // ... handle configuration exception
		      // ...  can happen before running JPF and indicates inconsistent configuration data
		    	cx.printStackTrace();
		    } catch (JPFException jx){
		      // ... handle exception while executing JPF, can be further differentiated into
		      // ...  JPFListenerException - occurred from within configured listener
		      // ...  JPFNativePeerException - occurred from within MJI method/native peer
		      // ...  all others indicate JPF internal errors
		    	jx.printStackTrace();
		    }
	}

}
