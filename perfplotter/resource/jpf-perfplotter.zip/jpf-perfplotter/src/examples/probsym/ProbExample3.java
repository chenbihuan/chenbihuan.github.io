package probsym;
/**
 * Probabilistic symbolic execution.
 * 
 * Deeply nested program to investigate how PCs are negated.
 */
public class ProbExample3 {

	public static void test(int x, int y, int z, int w, int q) {
		q = 0;
		if (x > y) {
			if (y > z) {
				if (w > z) {
					q = 1;
				} else {
					q = 2;
				}
			} else {
				if (w > z) {
					q = 3;
				} else {
					q = 4;
				}
			}
		} else {
			if (y > z) {
				if (w > z) {
					q = 5;
				} else {
					q = 6;
				}
			} else {
				if (w > z) {
					q = 7;
				} else {
					q = 8;
				}
			}
		}
	}

	public static void main(String[] args) {
		test(1, 4, 2, 3, 0);
	}

}
