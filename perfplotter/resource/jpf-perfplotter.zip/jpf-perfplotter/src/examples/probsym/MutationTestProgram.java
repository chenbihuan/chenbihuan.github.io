package probsym;

import gov.nasa.jpf.symbc.probsym.Analyze;

class MutationTestProgram {

	public static void covered(int br) {
		Analyze.coverage(""+br);
	}

	public static void test(int x) {
		if (x <= 3) {
			covered(1);
		} else {
			covered(2);
		}
	}

	public static void testSilly(int x) {
		int y = x;
		if (x > 10) {
			if (x == y) {
				covered(3);
			} else {
				covered(4);
			}
		} else {
			covered(5);
		}
	}

	public static void main(String[] Argv) {
		testSilly(5);
	}

}
