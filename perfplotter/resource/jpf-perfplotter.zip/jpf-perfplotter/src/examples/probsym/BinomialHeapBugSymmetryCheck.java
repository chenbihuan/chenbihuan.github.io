package probsym;

import probsym.BinomialHeapBug.BinomialHeapNodeBug;

public class BinomialHeapBugSymmetryCheck {

	public static native boolean symmetryCheck(BinomialHeapNodeBug n);
	
}
