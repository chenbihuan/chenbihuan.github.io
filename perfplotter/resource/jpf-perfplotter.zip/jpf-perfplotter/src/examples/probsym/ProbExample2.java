package probsym;
/**
 * Probabilistic symbolic execution.
 * 
 * Sample programs taken from
 * http://www.cs.sun.ac.za/~jaco/SIMPLE/index.html#exa  
 */
public class ProbExample2 {

	/**
	 * Fibonacci program
	 */
	public static void test004(int n) {
		int f1 = 0;
		int f2 = 1;
		while (n > 0) {
			int t = f2;
			f2 = f1 + f2;
			f1 = t;
			n--;
		}
		if (f1 == 5) {
			// Do something			
		}
	}

	/**
	 * Steve's program.  We check the final value of y.
	 */
	public static void test012A(int x, int y) {		
		if (x == y) {
			if (x == y) {
				x = 3;
			} else {
				y = 3;
			}
		} else {
			y = 3;
		}
		if (y == 3) {
			// Do something			
		}
	}
	
	/**
	 * Steve's program.  We check the final value of x.
	 */
	public static void test012B(int x, int y) {		
		if (x == y) {
			if (x == y) {
				x = 3;
			} else {
				y = 3;
			}
		} else {
			y = 3;
		}
		if (x == 3) {
			// Do something			
		}
	}
	
	public static void main(String[] args) {
		test004(1);
		// test012A(1,1);
		// test012B(1,1);
	}

}
